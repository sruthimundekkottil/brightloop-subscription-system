# Benchmark: What We Learned From Odoo Subscriptions

**Purpose:** compare our design with Odoo, the product this hackathon is named after, adopt what makes our system more correct, and be able to explain to reviewers where we follow Odoo and where we deliberately don't.

> **Update (revision 3).** After studying Kill Bill, two decisions below were superseded: discounts are now `discount` items linked to each base item, and taxes are `tax` items linked the same way, all in one `invoice_items` table. This replaces the per-tax-group discount lines (O12) and the `invoice_line_taxes` table (O8). The database is now MySQL 8.0. Everything else here still stands; see the UniBee and Kill Bill findings.

---

## 1. How this was investigated (and its limits)

| Source | What it gave us | Confidence |
|---|---|---|
| **Odoo 18.0 Community source on GitHub** (`odoo/odoo`, branch `18.0`) | Data models Odoo Subscriptions is built on: quotation templates, sales orders, product attributes and variant pricing, taxes, payment terms, invoices, payments, discount programs | **Observed.** Field definitions read directly from the files cited below |
| **Odoo Subscriptions app itself** (`sale_subscription`) | Recurring plans, subscription states, renewals, MRR, close reasons, recurring invoicing | **Not inspected.** It is an Enterprise (closed-source) module: `addons/sale_subscription` does not exist in the public repo (HTTP 404). Statements about it below come from general product knowledge and are marked *unverified* |
| **odoo.com/app/subscriptions** | Marketing page | **Not reached.** odoo.com is outside this environment's allowed network, so the page could not be loaded |

The reverse-engineering toolkit (REA) was not used: its own guidance says to use ordinary repository tools when the source is available, which is the case for everything we could inspect, and the closed Enterprise module could not be obtained.

**Before the presentation**, someone should verify the *unverified* items on a free Odoo trial (Subscriptions app) so no one states them as fact.

---

## 2. Findings ledger

### Observed in Odoo 18 Community source

| # | Finding | Evidence (file → field) | Our decision |
|---|---|---|---|
| O1 | Quotation templates carry lines, optional products, a validity in days, terms and conditions, and online signature/payment options | `sale_management/models/sale_order_template.py` → `number_of_days`, `note`, `sale_order_template_line_ids`, `sale_order_template_option_ids`, `require_signature`, `require_payment` | **Adopted:** `validity_days` and `terms` on templates. Optional products, signature and online payment → not adopted (see §4) |
| O2 | Without a template, quotation validity comes from a company-wide default | `sale/models/sale_order.py` → `_compute_validity_date` uses `company_id.quotation_validity_days` | **Adopted:** `company_settings.default_quotation_validity_days` (A) |
| O3 | Sales documents use states Quotation → Quotation Sent → Sales Order → Cancelled | `sale/models/sale_order.py` → `SALE_ORDER_STATE` | **Kept ours:** the problem statement prescribes Draft → Quotation → Confirmed → Active → Closed; Odoo's sales states map onto our first three |
| O4 | A variant's extra price lives on the **product × attribute value** pair, not on the global value or the variant | `product/models/product_template_attribute_value.py` → `price_extra`; `ptav_active` | **Adopted:** new `product_attribute_values` table with `price_extra`; variant price = base + sum of extras; used values archived, not deleted (B) |
| O5 | Attributes can create variants instantly, dynamically or never | `product/models/product_attribute.py` → `create_variant` (`always`, `dynamic`, `no_variant`) | **Simplified:** we always create explicit variants; noted as a known simplification |
| O6 | Invoices have a document state **and** a separate payment state | `account/models/account_move.py` → `state` (`draft`, `posted`, `cancel`) and `payment_state` (`not_paid`, `partial`, `in_payment`, `paid`, `reversed`, …) | **Adopted:** our `status` follows the problem; new generated `payment_status` (`not_paid`, `partial`, `paid`) (D) |
| O7 | Invoice numbers are assigned **when posted**, not when created; drafts are named "/", and Odoo tracks sequence gaps | `account/models/account_move.py` → `_compute_name` (only names when `state != 'draft'`), `made_sequence_gap` | **Adopted:** number assigned on confirm; DB check that confirmed invoices have a number (D) |
| O8 | A line can carry several taxes; taxes can be percent, fixed, group, or price-included | `account/models/account_move_line.py` → `tax_ids` (many-to-many); `account/models/account_tax.py` → `amount_type`, `price_include` | **Adopted:** multiple taxes per line, snapshotted in `invoice_line_taxes` (B, D). Percent and tax-exclusive only for the MVP |
| O9 | Payment terms are made of lines (percent or fixed, with delay rules such as "days after end of month") | `account/models/account_payment_term.py` → `value`, `value_amount`, `delay_type`, `nb_days` | **Simplified:** one `due_days` per term; installments not needed for the problem |
| O10 | Payments record amount, date, memo and method, and have their own states | `account/models/account_payment.py` → `amount`, `date`, `memo`, `payment_method_line_id`, `state` | **Confirms** our payment fields (method, amount, date, note) |
| O11 | Discount programs have validity dates, a usage limit, conditions (min quantity, min amount, products/categories) and rewards (percent or fixed, order or specific products, max amount) | `loyalty/models/loyalty_program.py` → `date_from`, `date_to`, `limit_usage`, `max_usage`, `trigger`; `loyalty_rule.py` → `minimum_qty`, `minimum_amount`, `product_ids`; `loyalty_reward.py` → `discount_mode`, `discount_applicability`, `discount_max_amount` | **Confirms** our discount rule design; **adopted** `max_discount_amount` (B) |
| O12 | Discounts are applied as **separate reward lines**, split by tax group | `sale_loyalty/models/sale_order.py` → reward lines (`is_reward_line`), `discountable_per_tax` | **Adopted:** discounts become their own negative invoice lines, one per tax group (B, D) |

### From product knowledge — *unverified, check on a trial*

| # | Finding | Our decision |
|---|---|---|
| K1 | Products are flagged as recurring, and one-time items can sit on the same subscription (e.g. setup fees) | **Adopted:** `products.is_recurring`; one-time lines billed on the first invoice only (B, D) |
| K2 | Renewal produces a **new renewal quotation** linked to the original, rather than editing the running subscription | **Adopted:** `renew` creates a linked subscription (`renewed_from_id`); the original closes as "Renewed" when the renewal activates (C) |
| K3 | Subscriptions store a monthly recurring amount, and reporting leads with **MRR**, ARR and churn | **Adopted and promoted to core:** `recurring_monthly` on subscriptions; MRR, ARR and churn on the dashboard (C, D). The problem itself says "nobody can say how much recurring revenue the company actually has" |
| K4 | Closing a subscription records a **close reason**, which drives churn analysis | **Adopted:** `close_reasons` table, reason required on close/cancel (C) |
| K5 | Recurring invoices are generated by a scheduled job from each subscription's next invoice date, and can be posted automatically | **Confirms** our billing engine; **adopted** optional `auto_confirm_recurring_invoices` setting (A, D) |
| K6 | Mid-term changes (upsells) are handled with prorated orders | **Partly adopted:** add/remove add-ons on active subscriptions, effective next period, no proration (C). Proration → stretch |
| K7 | Customers can pay by saved card and be charged automatically, with retries and automatic closing after unpaid days | **Not adopted:** requires a payment gateway (third-party dependency the guidelines discourage) |
| K8 | Customer portal for viewing, renewing, closing and paying subscriptions | **Confirms** our portal scope (pay online excluded, as K7) |

---

## 3. Summary of plan changes

| Area | Change | Owner |
|---|---|---|
| Variants | `price_extra` moved to new `product_attribute_values` (product × value); variant price computed | B |
| Products | `is_recurring` flag; one-time items billed once | B, D |
| Discounts | `max_discount_amount` cap; discount shown as separate negative lines split by tax group | B, D |
| Taxes | Several taxes per line, snapshotted in `invoice_line_taxes` | B, D |
| Templates | `terms`; default validity from company settings | C, A |
| Renewal | Creates a linked renewal subscription; original closes as "Renewed" | C |
| Closing | `close_reasons` table, reason required; churn reporting | C, D |
| MRR | `recurring_total` / `recurring_monthly` on subscriptions; MRR/ARR/churn on the dashboard (now **core**) | C, D |
| Add-ons | Add/remove lines on active subscriptions, effective next period | C |
| Invoices | Number assigned on confirm; generated `payment_status`; line types; period in line descriptions | D |
| Settings | New `company_settings` row: company details, currency, invoice prefix, default validity, auto-confirm | A |

---

## 4. Deliberately not adopted (and why)

| Odoo feature | Reason |
|---|---|
| Online card payments, saved tokens, automatic charging and payment retries | Needs a payment provider; guidelines discourage third-party dependencies. Payments are recorded manually as the problem describes |
| Electronic signature on quotations | Not in the problem; adds complexity without demo value |
| Optional products on templates | Nice for upselling, not required; candidate stretch |
| Prorated upsells | Correct proration is subtle; add-ons apply from the next period instead |
| Credit notes / invoice reversal | We cancel unpaid invoices only; credit notes are a stretch item |
| Installment payment terms, early-payment discounts | Not required; `due_days` covers the problem |
| Pricelists, multi-currency, multi-company, fiscal positions | Out of scope for Brightloop |
| Tax-included prices, fixed and group taxes | MVP supports percent, tax-exclusive; schema can extend |
| Dynamic / no-variant attributes | Explicit variants are simpler and sufficient |
| Sales-document state separate from subscription state | The problem prescribes one lifecycle; one enum keeps it explainable |

---

## 5. How to use this in the presentation

- Open with: "We studied how Odoo models the same problem and adopted what makes billing correct: invoice numbers on confirmation, discount lines per tax group, price extras per product and value, renewals as linked records, and MRR."
- Be explicit about what was **observed in source** versus **assumed about the Enterprise app**.
- Use §4 to show judgement: every omission has a reason tied to the problem statement or the guidelines.
