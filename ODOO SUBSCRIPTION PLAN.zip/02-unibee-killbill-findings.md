# Reverse Engineering: UniBee and Kill Bill

**Purpose:** study two open-source billing systems, match our stack to UniBee's, adopt Kill Bill's billing infrastructure where it makes billing more reliable, and record the evidence for every claim so the team can defend it in the presentation.

---

## 1. Method and limits

| Item | Detail |
|---|---|
| Sources read | `github.com/UniBee-Billing/unibee` (deployment repo) and its code repos `unibee-api`, `unibee-admin-portal`, `unibee-user-portal`; `github.com/killbill/killbill` (master, version `0.25.7-SNAPSHOT`) and enums from `killbill/killbill-api`; GoFrame `v2.6.4`; `shopspring/decimal v1.3.1`; `golang/crypto` |
| How | Static reading of the source. Both projects are ordinary source repositories, so normal repository tools were used rather than binary reverse-engineering tooling |
| Our own verification | Our MySQL schema was applied to **MySQL 8.0.46** (32 tables, 52 foreign keys, 38 check constraints) and passed **62/62** behavioural checks (`db/test_constraints.sh`); concurrency, deletion and performance were tested; Go-specific claims were checked with **Go 1.22.2** |
| Not done | Neither UniBee nor Kill Bill was run. Kill Bill's Java version is set in its parent POM, which wasn't inspected. The GoFrame decimal mapping is taken from GoFrame's source and documentation but must be confirmed by A's Phase 1 round-trip test. Timings come from this sandbox and must be re-measured on the team's machines |

---

## 2. Stack comparison and our choice

| Layer | UniBee (observed) | Kill Bill (observed) | **Ours** | Why |
|---|---|---|---|---|
| Language / framework | Go 1.22.5, GoFrame `v2.6.4` (`unibee-api/go.mod`) | Java; Maven modules; Guice, Jetty, Jersey (module POMs) | **Go 1.22 + GoFrame v2.6.4** | Matches UniBee exactly; Kill Bill's ideas are ported, not its Java stack |
| Database | MySQL 8.0.37 in Docker Compose; a PostgreSQL driver is also registered (`internal/driver/pgsql`) | MySQL, MariaDB and PostgreSQL (drivers and embedded-DB test modules); DDL is MySQL-first | **MySQL 8.0** | Common to both; allowed by the guidelines |
| Money | `bigint` cents (`amount, cent`); tax as `1000 = 10%` | `numeric(15,9)` | **`DECIMAL(12,2)` + `shopspring/decimal`** | Exact; UniBee already uses `shopspring/decimal` in Go |
| Locks / queues | Redis 6 (`SET NX EX` locks, `go-redismq`) | Database tables (`notifications`, `bus_events`) and a DB lock service | **MySQL only** (`FOR UPDATE SKIP LOCKED`, `job_queue`) | One less service; locks and jobs share the business transaction (see U7) |
| Scheduler | GoFrame `gcron.AddSingleton` | Notification queues (`next-billing-date-queue`) | **GoFrame `gcron.AddSingleton`** | Matches UniBee |
| Auth | `golang-jwt/jwt/v5` | — | **`golang-jwt/jwt/v5` + `x/crypto/bcrypt`** | Matches UniBee |
| PDF | `go-pdf/fpdf` | — | **`go-pdf/fpdf`** | Local library, no service |
| Email | SendGrid SDK | — | **`net/smtp` → MailHog** | Guidelines discourage third-party APIs |
| Migrations | Upgrades fetched from UniBee's platform API at start-up (`logic/dbupgrade/upgrade.go`) | DDL files | **golang-migrate SQL files** | Reproducible offline, as the guidelines require |
| Frontend | React 18, TypeScript, Vite, Ant Design 5, Zustand, axios, React Router 6 (both portals; user portal adds Tailwind) | Separate admin UI (not inspected) | **React 18 + TypeScript + Vite + Ant Design 5 + Zustand + axios + React Router 6** | Matches UniBee; one design system (no Tailwind) |
| Deployment | Docker Compose + Nginx | — | **Docker Compose** (MySQL, MailHog, API, web) | Matches UniBee; one-command setup |

---

## 3. UniBee findings

| # | Finding | Evidence | Decision |
|---|---|---|---|
| U1 | The linked repo holds deployment files only; code lives in three other repos | `unibee/README.md`, `docker-compose.yaml` | — |
| U2 | 39 tables, **no foreign keys** | `mysql/structure.sql` (`FOREIGN KEY` count: 0) | **Not adopted.** We keep 52 foreign keys; the guidelines value them |
| U3 | Invoice lines are stored as JSON text | `invoice.lines text COMMENT 'lines( json)'` | **Not adopted.** We use `invoice_items` rows |
| U4 | Billing: two singleton jobs every 10 s pick up to 10 subscriptions whose `dunning_time` has passed | `internal/cronjob/cronjob.go`, `internal/cronjob/sub/subscription.go` | **Adopted** the polling + `AddSingleton` pattern |
| U5 | Whether to invoice is decided in code from the latest invoice's status and period; there is no unique key per subscription period | `logic/subscription/billingcycle/cycle/cycle.go` (`needInvoiceGenerate`); invoice unique key is only `unique_id` | **Improved on:** `billing_records UNIQUE (subscription_id, period_start)` |
| U6 | Per-subscription lock: Redis `SET key 1 NX EX 60` | `utility/jedis.go` `TryLock` | **Replaced** by a MySQL row lock |
| U7 | The lock is released with `DEL` without checking its value | `utility/jedis.go` `ReleaseLock` | Reason for U6: a worker that outlives the 60 s expiry can delete another worker's lock |
| U8 | Subscriptions carry `billing_cycle_anchor`, `current_period_start/end`, `cancel_at_period_end`, `trial_end` | `subscription` table | **Adopted** anchor and end-of-term close |
| U9 | Per-subscription **test clock**, forward-only, capped, excluded from production billing | `billingcycle/testclock/testclock.go`, `cronjob/sub/subscription.go` | **Adopted** as a global development-only, forward-only clock |
| U10 | Plans: `interval_unit` (day/week/month/year) + `interval_count`; main / recurring add-on / one-time add-on types | `plan` table | **Adopted** `billing_interval_count` and one-time products |
| U11 | Discount codes: percentage or fixed, `user_limit`, `subscription_limit`, `cycle_limit`, dates; usage rows with status `1-normal, 2-rollback` | `merchant_discount_code`, `merchant_user_discount_code` | **Adopted** per-customer and per-subscription-cycle limits; reversal on cancel |
| U12 | Scheduled plan changes with proration | `subscription_pending_update` | Stretch |
| U13 | Idempotency via `unique_id` unique keys on invoice, payment, timeline | `structure.sql` | **Adopted** for payments |
| U14 | Operation log and async export tasks | `merchant_operation_log`, `merchant_batch_task` | **Adopted** audit log; exports are stretch |
| U15 | API structs with `g.Meta` route tags; admin (`api/merchant`) and customer (`api/user`) split; updates often `POST .../update` | `unibee-api/api/` | **Adopted** structs and the admin/portal split; we keep resource-style routes |
| U16 | Stripe, SendGrid, VAT services, multi-merchant (`merchant_id` everywhere) | `go.mod`, `structure.sql` | **Not adopted** (third-party, out of scope) |

---

## 4. Kill Bill findings

| # | Finding | Evidence | Decision |
|---|---|---|---|
| K1 | Every invoice amount is a row in `invoice_items` with a `type`, a service period (`start_date`, `end_date`) and `linked_item_id`; items have only `created_*` columns (append-only) | `invoice/src/main/resources/.../invoice/ddl.sql` | **Adopted:** `invoice_items` with `recurring`, `fixed`, `discount`, `tax`, linked and append-only |
| K2 | Item types: `EXTERNAL_CHARGE, FIXED, RECURRING, REPAIR_ADJ, CBA_ADJ, CREDIT_ADJ, ITEM_ADJ, USAGE, TAX, PARENT_SUMMARY` | `killbill-api` `InvoiceItemType.java` | Subset adopted; adjustments, credits and usage are stretch / out of scope |
| K3 | Invoice statuses `DRAFT, COMMITTED, VOID` | `killbill-api` `InvoiceStatus.java` | Map to our draft / confirmed / cancelled; "paid" from the problem statement |
| K4 | The generator builds "ALL items since beginning of time", merges them with existing items and writes only the difference | `generator/FixedAndRecurringInvoiceItemGenerator.java` (`generateItems`) | **Adopted** as expected periods minus `billing_records` |
| K5 | Safety bounds: duplicate-item sanity check on by default; max **15** items per subscription per day | same file (`safetyBounds`); `util/.../InvoiceConfig.java` defaults | **Adopted:** max 31 periods per subscription per run |
| K6 | Global lock per account around invoicing and payments; not taken for dry runs | `InvoiceDispatcher.java` (`ACCNT_INV_PAY`) | **Adapted:** row locks on the subscription (billing) and invoice (payments); discount rows locked in id order |
| K7 | Dry-run invoices | `InvoiceDispatcher.java` (`DryRunArguments`) | **Adopted:** upcoming-invoice preview, dry-run billing runs |
| K8 | DB-backed queues: `notifications`, `bus_events` with `processing_state` (default `AVAILABLE`), `processing_owner`, `processing_available_date`, `error_count`, `effective_date` | `util/src/main/resources/.../util/ddl.sql` | **Adopted:** `job_queue` |
| K9 | `audit_log` (`table_name`, `target_record_id`, `change_type`, `reason_code`, `comments`) and a `*_history` table per entity | same `ddl.sql`; module DDLs | **Adopted** `audit_log`; history only for subscription status |
| K10 | Test-mode `ClockMock` behind a test endpoint, with a warning that moving the clock back and forth may cause weird side effects | `jaxrs/.../resources/TestResource.java` | **Adopted** (forward-only) |
| K11 | `payments.external_key` unique per tenant | `payment/.../ddl.sql` (`payments_key`) | **Adopted:** `payments.idempotency_key` |
| K12 | Pause/blocking via `blocking_states` (`block_change`, `block_entitlement`, `block_billing`, `effective_date`) | `entitlement/.../ddl.sql` | Our `paused` status blocks billing; effective-dated blocking is stretch |
| K13 | Cancellation policies `IMMEDIATE`, `END_OF_TERM`; billing policies `START_OF_TERM`, `END_OF_TERM`, `IMMEDIATE`; `UNCANCEL` event | `killbill-api` `Entitlement.java`, `BillingActionPolicy.java`; `subscription/.../ApiEventType.java` | **Adopted:** close now / at end of period, `undo_close` |
| K14 | Bill cycle day per account; alignment `ACCOUNT, BUNDLE, SUBSCRIPTION` | `account/.../ddl.sql` (`billing_cycle_day_local`); `BillingAlignment.java` | **Adopted** subscription alignment via `billing_anchor_date` |
| K15 | Snapshot of billing events per invoice | `invoice_billing_events` | **Adopted:** `billing_records.inputs` JSON |
| K16 | Subscriptions are event-sourced (`subscription_events`: `CREATE, CHANGE, CANCEL, UNDO_CHANGE, UNCANCEL`, `PHASE`, `BCD_UPDATE`, …) | `subscription/.../ddl.sql`, `ApiEventType.java`, `SubscriptionBaseEvent.java` | **Not adopted:** status + history table is enough for this problem and easier to explain |
| K17 | No foreign keys in any DDL; internal `record_id` plus external UUID `id`; invoice number = `record_id` | DDL files (count 0); `InvoiceSqlDao.sql.stg` | **Not adopted:** we keep FKs and gapless numbers on confirm |
| K18 | Multi-tenancy, plugins, usage billing, parent/child invoices, credit balance (`CBA_ADJ`) | module list, DDL | Out of scope / stretch |

---

## 5. Verified technical facts that changed our plan

| # | Fact | How verified | Effect |
|---|---|---|---|
| V1 | Go's `regexp` (RE2) rejects lookaheads: `invalid or unsupported Perl syntax: (?=` | Compiled with Go 1.22.2 | Password rule checked as separate patterns (A) |
| V2 | GoFrame's `password3` rule is 6–18 characters and requires a digit | `gvalid/internal/builtin/builtin_password3.go` | Not used; custom rule (A) |
| V3 | bcrypt returns `ErrPasswordTooLong` above 72 bytes | `golang/crypto` `bcrypt/bcrypt.go` | Max 72 bytes (A) |
| V4 | `gf gen dao` maps `decimal` to `float64` by default; `typeMapping` can map it to `decimal.Decimal` | `cmd/gf/internal/cmd/gendao/gendao.go` (`defaultTypeMapping`, example config) | Mandatory config + round-trip test (A) |
| V5 | GoFrame `LockUpdate()` emits only `FOR UPDATE` | `database/gdb/gdb_model_lock.go` | `SKIP LOCKED` in raw SQL (D) |
| V6 | `decimal.Round` documents `5.45 → 5.5` (half away from zero) | `shopspring/decimal v1.3.1` source | Rounding rule stated precisely (B) |
| V7 | `time.AddDate` normalises: 31 Jan + 1 month = 3 Mar (2026) | Go test in `reference/billingdate` | Clamped month arithmetic (C) |
| V8 | PostgreSQL sequences don't roll back; a MySQL counter row does | MySQL test (counter unchanged after rollback) | Gapless numbers via `number_sequences` (A, D); corrects our earlier "no gaps" claim |
| V9 | MySQL has no partial indexes or case-insensitive text type | MySQL 8.0 behaviour; generated-column workarounds tested | Single default tax, one open renewal, case-insensitive email (A, B, C) |
| V10 | MySQL blocks deleting a parent item while linked items reference it | Deletion test (error 1451) | Invoices are never deleted; no cascades on invoice children (D) |
| V11 | `SKIP LOCKED` returns immediately without the locked row | Two sessions: `[11,12]` returned in 0.01 s while 10 was locked | Basis of concurrent billing (D) |
| V12 | Dashboard and billing queries take 8–99 ms on 10,000 subscriptions / 100,000 invoices | Seeded MySQL timings | Two-second target credible; re-measure in Phase 4 (D) |

---

## 6. How to use this in the presentation

- "We matched UniBee's stack (Go, GoFrame, MySQL, React and Ant Design) and ported Kill Bill's billing infrastructure: typed and linked invoice items, compute-and-diff billing with safety bounds, dry runs, a database job queue, an audit log and a test clock."
- "Where we deliberately differ, it's to follow the guidelines: foreign keys everywhere, no Redis, no third-party email or payments, no JSON business data, and a database constraint that makes double billing impossible."
- Every claim above has a source file; say "observed in the source" or "verified on MySQL 8.0", never more.
