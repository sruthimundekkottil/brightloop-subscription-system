# Member B — Catalog & Pricing

**Project:** Brightloop Subscription Management System
**Stack:** Go 1.22 + GoFrame v2.6.4 · MySQL 8.0 · React 18 + TypeScript + Vite + Ant Design 5
**Modules owned:** Products, attributes and variants, plans, tax rules, discount rules, and the shared **pricing service**

---

## 1. Your mission

You own everything the admin configures, and the single source of truth for **how money is calculated**. C uses your pricing service to price quotations and subscription lines; D uses it to build every invoice item: the base items, the discount items and the tax items. If pricing lives in one Go package, the numbers on a quotation, a preview and an invoice always agree.

---

## 2. Database tables you own

Copied from `db/migrations/000001_init.up.sql` (applied to MySQL 8.0.46; all 62 checks in `db/test_constraints.sh` pass).

```sql
CREATE TABLE products (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name         VARCHAR(150) NOT NULL,
    product_type VARCHAR(50) NOT NULL,                    -- 'software', 'addon', 'service'
    sales_price  DECIMAL(12,2) NOT NULL,
    cost_price   DECIMAL(12,2) NOT NULL,
    notes        TEXT NULL,
    is_recurring BOOLEAN NOT NULL DEFAULT TRUE,           -- FALSE = one-time item, billed on the first invoice only
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,           -- archive, never delete
    created_at   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_products_active_name (is_active, name),
    CONSTRAINT chk_products_sales_price CHECK (sales_price >= 0),
    CONSTRAINT chk_products_cost_price  CHECK (cost_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE product_attributes (
    id   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,                            -- 'Brand'
    PRIMARY KEY (id),
    UNIQUE KEY uq_attribute_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE attribute_values (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    attribute_id BIGINT UNSIGNED NOT NULL,
    value        VARCHAR(80) NOT NULL,                    -- 'Odoo'
    PRIMARY KEY (id),
    UNIQUE KEY uq_attribute_value (attribute_id, value),
    CONSTRAINT fk_attr_values_attribute FOREIGN KEY (attribute_id) REFERENCES product_attributes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- price_extra per product × value (as Odoo's product.template.attribute.value)
CREATE TABLE product_attribute_values (
    id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id         BIGINT UNSIGNED NOT NULL,
    attribute_value_id BIGINT UNSIGNED NOT NULL,
    price_extra        DECIMAL(12,2) NOT NULL DEFAULT 0, -- Brand = Odoo → 560.00 (may be negative; final price checked ≥ 0 in service)
    is_active          BOOLEAN NOT NULL DEFAULT TRUE,     -- archived, not deleted, once used
    PRIMARY KEY (id),
    UNIQUE KEY uq_product_attr_value (product_id, attribute_value_id),
    CONSTRAINT fk_pav_product FOREIGN KEY (product_id)         REFERENCES products (id) ON DELETE CASCADE,
    CONSTRAINT fk_pav_value   FOREIGN KEY (attribute_value_id) REFERENCES attribute_values (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE product_variants (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    product_id BIGINT UNSIGNED NOT NULL,
    name       VARCHAR(150) NOT NULL,                     -- 'CRM Suite (Odoo)'
    is_active  BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (id),
    KEY idx_variants_product (product_id),
    CONSTRAINT fk_variants_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE product_variant_values (
    variant_id                 BIGINT UNSIGNED NOT NULL,
    product_attribute_value_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (variant_id, product_attribute_value_id),
    CONSTRAINT fk_pvv_variant FOREIGN KEY (variant_id)                 REFERENCES product_variants (id)         ON DELETE CASCADE,
    CONSTRAINT fk_pvv_pav     FOREIGN KEY (product_attribute_value_id) REFERENCES product_attribute_values (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE plans (
    id                     BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name                   VARCHAR(150) NOT NULL,
    price                  DECIMAL(12,2) NOT NULL,
    billing_period         ENUM('daily', 'weekly', 'monthly', 'yearly') NOT NULL,
    billing_interval_count SMALLINT UNSIGNED NOT NULL DEFAULT 1,  -- e.g. 3 × monthly = quarterly (UniBee interval_count)
    min_quantity           INT UNSIGNED NOT NULL DEFAULT 1,
    available_from         DATE NOT NULL,
    available_until        DATE NULL,
    auto_close             BOOLEAN NOT NULL DEFAULT FALSE,
    can_close_early        BOOLEAN NOT NULL DEFAULT TRUE,
    can_pause              BOOLEAN NOT NULL DEFAULT FALSE,
    can_renew              BOOLEAN NOT NULL DEFAULT TRUE,
    is_active              BOOLEAN NOT NULL DEFAULT TRUE,
    created_at             DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at             DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT chk_plans_price          CHECK (price >= 0),
    CONSTRAINT chk_plans_interval_count CHECK (billing_interval_count >= 1),
    CONSTRAINT chk_plans_min_quantity   CHECK (min_quantity >= 1),
    CONSTRAINT chk_plans_availability   CHECK (available_until IS NULL OR available_until >= available_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE tax_rules (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name           VARCHAR(80) NOT NULL,                  -- 'GST 18%'
    rate_percent   DECIMAL(5,2) NOT NULL,
    is_default     BOOLEAN NOT NULL DEFAULT FALSE,
    is_active      BOOLEAN NOT NULL DEFAULT TRUE,
    default_marker TINYINT UNSIGNED GENERATED ALWAYS AS (IF(is_default, 1, NULL)) STORED, -- MySQL has no partial indexes
    PRIMARY KEY (id),
    UNIQUE KEY uq_tax_name (name),
    UNIQUE KEY uq_tax_single_default (default_marker),
    CONSTRAINT chk_tax_rate CHECK (rate_percent >= 0 AND rate_percent <= 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE product_tax_rules (
    product_id  BIGINT UNSIGNED NOT NULL,
    tax_rule_id BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (product_id, tax_rule_id),
    CONSTRAINT fk_ptr_product FOREIGN KEY (product_id)  REFERENCES products (id) ON DELETE CASCADE,
    CONSTRAINT fk_ptr_tax     FOREIGN KEY (tax_rule_id) REFERENCES tax_rules (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE discount_rules (
    id                          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name                        VARCHAR(120) NOT NULL,
    discount_type               ENUM('fixed', 'percentage') NOT NULL,
    value                       DECIMAL(12,2) NOT NULL,
    scope                       ENUM('subscription', 'products') NOT NULL,
    customer_id                 BIGINT UNSIGNED NULL,     -- NULL = any customer
    min_purchase_amount         DECIMAL(12,2) NULL,
    min_quantity                INT UNSIGNED NULL,
    starts_on                   DATE NOT NULL,
    ends_on                     DATE NOT NULL,
    max_uses                    INT UNSIGNED NULL,        -- total uses; NULL = unlimited
    max_uses_per_customer       INT UNSIGNED NULL,        -- UniBee user_limit
    max_cycles_per_subscription INT UNSIGNED NULL,        -- UniBee cycle_limit: first N billing cycles only
    max_discount_amount         DECIMAL(12,2) NULL,       -- cap per invoice (Odoo discount_max_amount)
    times_used                  INT UNSIGNED NOT NULL DEFAULT 0,  -- incremented/decremented by D in the billing transaction
    is_active                   BOOLEAN NOT NULL DEFAULT TRUE,
    created_by                  BIGINT UNSIGNED NOT NULL,
    created_at                  DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_discounts_active_dates (is_active, starts_on, ends_on),
    CONSTRAINT fk_discount_customer   FOREIGN KEY (customer_id) REFERENCES customers (id),
    CONSTRAINT fk_discount_created_by FOREIGN KEY (created_by)  REFERENCES users (id),
    CONSTRAINT chk_discount_value      CHECK (value > 0),
    CONSTRAINT chk_discount_percentage CHECK (discount_type <> 'percentage' OR value <= 100),
    CONSTRAINT chk_discount_dates      CHECK (ends_on >= starts_on),
    CONSTRAINT chk_discount_min_amount CHECK (min_purchase_amount IS NULL OR min_purchase_amount >= 0),
    CONSTRAINT chk_discount_min_qty    CHECK (min_quantity IS NULL OR min_quantity >= 1),
    CONSTRAINT chk_discount_max_uses   CHECK (max_uses IS NULL OR max_uses >= 1),
    CONSTRAINT chk_discount_usage      CHECK (max_uses IS NULL OR times_used <= max_uses),
    CONSTRAINT chk_discount_cap        CHECK (max_discount_amount IS NULL OR max_discount_amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE discount_rule_products (
    discount_rule_id BIGINT UNSIGNED NOT NULL,
    product_id       BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (discount_rule_id, product_id),
    CONSTRAINT fk_drp_rule    FOREIGN KEY (discount_rule_id) REFERENCES discount_rules (id) ON DELETE CASCADE,
    CONSTRAINT fk_drp_product FOREIGN KEY (product_id)       REFERENCES products (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Design decisions to be able to explain**

- Variants are built from **generic attributes**, so "Odoo adds 560" is a row, not hard-coded logic.
- `price_extra` lives on the **product × attribute value** pair, where Odoo keeps it (`product.template.attribute.value.price_extra`). A variant's price is always `sales_price + SUM(price_extra)` of its values, never typed in.
- `is_recurring = FALSE` marks one-time items (a setup fee), billed on the first invoice only.
- `billing_interval_count` lets one plan bill every N periods (3 × monthly = quarterly), as UniBee's `interval_count` does. It defaults to 1, so the problem's daily/weekly/monthly/yearly work unchanged.
- **Only one default tax rule:** MySQL has no partial indexes, so `default_marker` is a generated column that is 1 for the default rule and NULL otherwise; a `UNIQUE` index allows many NULLs but only one 1 (tested).
- `times_used` is `UNSIGNED` with `CHECK (times_used <= max_uses)`: the database refuses both over-use and a negative count (both tested).
- Discount limits beyond the problem's total `max_uses`, adopted from UniBee's discount codes (`user_limit`, `cycle_limit`): `max_uses_per_customer` and `max_cycles_per_subscription` ("first 3 months at 20% off"). Both optional.
- `max_discount_amount` caps a percentage discount per invoice (Odoo's `discount_max_amount`).
- Products are archived, never deleted, because invoices reference them.

**Decision to confirm in the kickoff:** the plan price is billed as its own recurring item each period; recurring product lines (seats, add-ons) are billed per period at their unit price; one-time products on the first invoice only.

---

## 3. The pricing service (your most important deliverable)

A pure Go package (`internal/logic/pricing`) with no HTTP code, tested with `testing` + `testify`. All money is `decimal.Decimal`.

| Function | Returns | Used by |
|---|---|---|
| `UnitPrice(ctx, productID, variantID)` | `sales_price + SUM(price_extra)`; error if below 0 | C |
| `TaxRulesFor(ctx, productID)` | Active rules assigned to the product, else the default rule | C, D |
| `IsPlanAvailable(plan, date)` | bool + reason | C |
| `ApplicableDiscounts(ctx, tx, dctx)` | Eligible rules, **rows locked** `FOR UPDATE` in ascending id order | D |
| `PriceItems(baseItems, discounts, taxRules)` | Base items + **linked** discount items + **linked** tax items, all rounded | C (preview), D (invoice) |

### The item model (from Kill Bill)

Kill Bill puts every amount on an invoice into one `invoice_items` table with a `type` (`RECURRING`, `FIXED`, `TAX`, `ITEM_ADJ`, …) and a `linked_item_id` that points at the item an adjustment applies to. We use the same idea with four types:

| Type | Example | Linked to | Sign |
|---|---|---|---|
| `recurring` | "CRM Suite (Odoo) × 12 seats · 1–31 Mar" | — | ≥ 0 |
| `fixed` | "Setup fee" (one-time product) | — | ≥ 0 |
| `discount` | "Seat volume 10%" | the item it reduces | < 0 |
| `tax` | "GST 18%" | the item it taxes | ≥ 0 |

The database enforces these rules with `CHECK` constraints (all tested): discount and tax items must be linked, other items must not; only discount items may be negative; a tax item must carry a tax rule.

### Calculation rules (write them into the README)

1. **Base items:** `amount = round2(quantity × unit_price)`.
2. **Discounts:** a percentage discount gives each in-scope base item its own discount item, `−round2(item × rate)`. A fixed discount is split across in-scope items in proportion to their amounts, with the rounding remainder on the last item. `max_discount_amount` caps the total the same way. A discount never exceeds the item it reduces.
3. **Taxes:** for each base item and each of its tax rules, a tax item `round2((item + its discount items) × rate)`. Tax is therefore always on the discounted amount, item by item.
4. **Totals:** `subtotal` = Σ base items; `discount_total` = −Σ discount items; `tax_total` = Σ tax items; `total` = Σ all items.
5. **Rounding:** `decimal.Round(2)`. Its source documents `5.45 → 5.5`, i.e. half away from zero; we only round positive amounts (discounts are computed positive, then negated), so this equals half-up.
6. **Stacking:** apply the single best eligible discount per invoice (agree in kickoff).
7. **Display:** the printed invoice groups discount items by rule and tax items by rate ("GST 18% on 4,500.00: 810.00").

### Discount eligibility (`ApplicableDiscounts`)

A rule applies only if all are true:

1. `is_active` and `starts_on <= today <= ends_on` (today from A's `clock.Today`)
2. `max_uses IS NULL OR times_used < max_uses`
3. `customer_id IS NULL OR customer_id = invoice customer`
4. `max_uses_per_customer`: count of this customer's non-reversed `discount_applications` for the rule is below it
5. `max_cycles_per_subscription`: count of this subscription's non-reversed applications is below it
6. `min_purchase_amount` / `min_quantity`: met by the in-scope base items
7. Scope `products`: only items whose product is in `discount_rule_products`; scope `subscription`: all base items

Lock eligible rule rows **in ascending id order** inside D's transaction, so two billing workers can't deadlock and can't both take the last use.

---

## 4. API endpoints you own

Writes: admin only. Reads: admin and staff.

| Method | Route | Notes |
|---|---|---|
| GET/POST | `/api/products` | Search, type, active; paginated |
| GET/PATCH | `/api/products/{id}` | With values, variants, taxes |
| POST | `/api/products/{id}/archive` | Soft delete |
| GET/POST | `/api/attributes` | With values |
| POST | `/api/attributes/{id}/values` | |
| PUT | `/api/products/{id}/attribute-values` | Offered values with `price_extra`; removing a used value archives it |
| GET/POST | `/api/products/{id}/variants` | Created from chosen values; price computed |
| GET/POST | `/api/plans` | Filter: active, available on a date |
| GET/PATCH | `/api/plans/{id}` | Lifecycle flags, interval count |
| GET/POST | `/api/tax-rules` | Only one default (DB-enforced) |
| PATCH | `/api/tax-rules/{id}` | |
| PUT | `/api/products/{id}/tax-rules` | |
| GET/POST | `/api/discount-rules` | Filter: active, scheduled, expired, used up |
| GET/PATCH | `/api/discount-rules/{id}` | Can't lower `max_uses` below `times_used` (DB-enforced) |
| POST | `/api/pricing/preview` | Lines in → items, subtotal, discounts, taxes, total out |

Every write calls A's `audit.Log` in the same transaction.

---

## 5. Frontend you own

Ant Design 5 tables, forms and tags throughout.

- **Products:** list (search, type, archived toggle); form with sales and cost price, notes, "Recurring" switch; margin shown.
- **Attributes & variants:** attribute admin; on the product page, offered values with price extras, then variants built from them with the computed price shown.
- **Plans:** form with period, "every N" count, minimum quantity, availability dates and the four lifecycle switches with helper text.
- **Taxes:** list and form; mark default; assign on the product form.
- **Discounts:** list with status tags (*Active*, *Scheduled*, *Expired*, *Used up*) and a usage `Progress` bar; form that adapts to type and scope, with the optional limits under an "Advanced" section.

---

## 6. What you depend on from others

| From | What | When |
|---|---|---|
| A | Middleware, error mapping, `clock`, `audit`, UI kit; `customers` table | Phase 1 |
| D | Calls `ApplicableDiscounts` and `PriceItems` inside its billing transaction, then writes `discount_applications` and increments `times_used` | Phase 2 |

---

## 7. Phase-by-phase checklist

**Phase 0 — Kickoff (with team)**
- [ ] Walk through your tables in the schema; agree plan-price rule, stacking, rounding

**Phase 1 — Foundation**
- [ ] Catalog and plan CRUD APIs with validation
- [ ] **Pricing service stub** with the agreed signatures, so C and D aren't blocked

**Phase 2 — Core workflows**
- [ ] Full pricing service with unit tests (section 8)
- [ ] Taxes, discounts, all admin screens; `/api/pricing/preview`
- [ ] **Checkpoint 2 (team):** a subscription produces a correct invoice with linked discount and tax items

**Phase 3 — Integration**
- [ ] Pair with D on locking order and limits inside the billing transaction

**Phase 4 — Testing and hardening**
- [ ] Tests in section 8

**Phase 5 — Demo prep**
- [ ] Seed: products, Brand attribute with Odoo (+560), monthly/yearly/quarterly plans, two tax rules, active and expired discounts

---

## 8. Tests and edge cases you must cover

- Odoo variant → unit price = sales price + 560; same "Odoo" value with a different extra on another product
- Product with two taxes → two tax items per base item, each rounded
- 3 × 33.33 with 18% tax → items and totals correct to the cent
- Percentage discount over items with different tax rates → each item's tax computed on its own discounted amount
- Fixed discount split across three items → parts sum exactly to the discount
- Fixed discount larger than the subtotal → capped; `max_discount_amount` caps a percentage discount
- Discount expired, used up, for another customer, below minimums, over per-customer or per-subscription limits → not applied
- Database rejections (already in `test_constraints.sh`): percentage over 100, end before start, two default taxes, `times_used` over `max_uses` or below zero
- Staff creating a discount → 403

---

## 9. Git branches (suggested)

`feature/catalog-products`, `feature/catalog-variants`, `feature/plans`, `feature/tax-rules`, `feature/discount-rules`, `feature/pricing-service`

---

## 10. Your demo segment

1. As admin, create a product, add Brand = Odoo (+560), and show the variant price computed automatically.
2. Create a monthly plan and a quarterly plan (every 3 months); explain the lifecycle switches.
3. Create a tax rule and a 10% discount with a minimum of 10 seats, 5 total uses and a 3-cycle limit.
4. Open the pricing preview: base item, its linked discount item, its linked tax item.
5. Log in as staff and show discount creation is blocked.

---

## 11. Questions you should be ready to answer

- Why do discount and tax items link to the item they apply to (Kill Bill's `linked_item_id`)?
- Why does `price_extra` sit on the product × value pair?
- How does MySQL guarantee a single default tax rule without partial indexes?
- How does the database stop a discount being over-used, even under concurrent billing?
- Why lock discount rows in ascending id order?
- How does the full flow work from signup to dashboard? (Explain A, C and D at a high level.)
