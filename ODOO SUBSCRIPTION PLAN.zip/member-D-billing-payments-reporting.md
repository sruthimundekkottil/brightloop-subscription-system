# Member D — Billing, Payments & Reporting

**Project:** Brightloop Subscription Management System
**Stack:** Go 1.22 + GoFrame v2.6.4 · MySQL 8.0 · React 18 + TypeScript + Vite + Ant Design 5
**Modules owned:** Recurring billing engine, invoices and invoice items, invoice actions and PDF, discount applications, payments, overdue reminders, the finance dashboard, portal "My Invoices", seed data and performance testing

---

## 1. Your mission

On billing day hundreds of subscriptions are due at once. Your engine must create every invoice that is due, **never twice and never skipped**, even when it is re-run, crashes halfway, or two workers run at the same time. Then you track the money: payments, balances, overdue invoices, and the finance dashboard, which must answer in **under two seconds** with thousands of subscriptions.

---

## 2. Database tables you own

Copied from `db/migrations/000001_init.up.sql` (applied to MySQL 8.0.46; all 62 checks in `db/test_constraints.sh` pass).

```sql
CREATE TABLE invoices (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    number          VARCHAR(30) NULL,                     -- NULL while draft; assigned on confirm
    customer_id     BIGINT UNSIGNED NOT NULL,
    subscription_id BIGINT UNSIGNED NULL,
    status          ENUM('draft', 'confirmed', 'paid', 'cancelled') NOT NULL DEFAULT 'draft',
    invoice_date    DATE NOT NULL,
    due_date        DATE NOT NULL,
    period_start    DATE NULL,
    period_end      DATE NULL,
    billing_name    VARCHAR(150) NOT NULL,                -- customer snapshot
    billing_address TEXT NULL,
    subtotal        DECIMAL(12,2) NOT NULL DEFAULT 0,     -- recurring + fixed items
    discount_total  DECIMAL(12,2) NOT NULL DEFAULT 0,     -- positive number (sum of negative discount items, sign flipped)
    tax_total       DECIMAL(12,2) NOT NULL DEFAULT 0,
    total           DECIMAL(12,2) NOT NULL DEFAULT 0,     -- = SUM(invoice_items.amount)
    amount_paid     DECIMAL(12,2) NOT NULL DEFAULT 0,     -- maintained in the payment transaction
    payment_status  VARCHAR(10) GENERATED ALWAYS AS (
                        CASE WHEN amount_paid = 0 THEN 'not_paid'
                             WHEN amount_paid < total THEN 'partial'
                             ELSE 'paid' END) STORED,
    confirmed_at    DATETIME(3) NULL,
    sent_at         DATETIME(3) NULL,
    cancelled_at    DATETIME(3) NULL,
    cancel_reason   VARCHAR(200) NULL,
    created_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_invoices_number (number),               -- multiple NULLs allowed (drafts)
    KEY idx_invoices_status_due (status, due_date),
    KEY idx_invoices_date (invoice_date),
    CONSTRAINT fk_invoices_customer     FOREIGN KEY (customer_id)     REFERENCES customers (id),
    CONSTRAINT fk_invoices_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id),
    CONSTRAINT chk_invoices_total       CHECK (total >= 0),
    CONSTRAINT chk_invoices_paid_range  CHECK (amount_paid >= 0 AND amount_paid <= total),
    CONSTRAINT chk_invoices_due         CHECK (due_date >= invoice_date),
    CONSTRAINT chk_invoices_numbered    CHECK (status IN ('draft', 'cancelled') OR number IS NOT NULL),
    CONSTRAINT chk_invoices_paid_status CHECK (status <> 'paid' OR amount_paid = total),
    CONSTRAINT chk_invoices_period      CHECK (period_end IS NULL OR period_end >= period_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- One table for every amount on an invoice (Kill Bill invoice_items pattern).
-- Items are append-only and invoices are never deleted (drafts are cancelled), so no ON DELETE CASCADE here.
CREATE TABLE invoice_items (
    id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    invoice_id       BIGINT UNSIGNED NOT NULL,
    item_type        ENUM('recurring', 'fixed', 'discount', 'tax') NOT NULL,
    linked_item_id   BIGINT UNSIGNED NULL,                -- discount/tax items point at the item they apply to
    product_id       BIGINT UNSIGNED NULL,                -- NULL for the plan line, discounts and taxes
    plan_id          BIGINT UNSIGNED NULL,
    discount_rule_id BIGINT UNSIGNED NULL,
    tax_rule_id      BIGINT UNSIGNED NULL,
    description      VARCHAR(255) NOT NULL,               -- snapshot, e.g. 'CRM Suite (Odoo) · 1 Mar – 31 Mar 2026'
    service_start    DATE NULL,                           -- service period of recurring items
    service_end      DATE NULL,
    quantity         INT UNSIGNED NOT NULL DEFAULT 1,
    unit_price       DECIMAL(12,2) NULL,                  -- snapshot for recurring/fixed items
    rate_percent     DECIMAL(5,2) NULL,                   -- snapshot: tax rate or discount percentage
    amount           DECIMAL(12,2) NOT NULL,              -- negative only for discount items
    created_at       DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_items_invoice (invoice_id),
    KEY idx_items_linked (linked_item_id),
    CONSTRAINT fk_items_invoice  FOREIGN KEY (invoice_id)       REFERENCES invoices (id),   -- invoices are never deleted
    CONSTRAINT fk_items_linked   FOREIGN KEY (linked_item_id)   REFERENCES invoice_items (id),
    CONSTRAINT fk_items_product  FOREIGN KEY (product_id)       REFERENCES products (id),
    CONSTRAINT fk_items_plan     FOREIGN KEY (plan_id)          REFERENCES plans (id),
    CONSTRAINT fk_items_discount FOREIGN KEY (discount_rule_id) REFERENCES discount_rules (id),
    CONSTRAINT fk_items_tax      FOREIGN KEY (tax_rule_id)      REFERENCES tax_rules (id),
    CONSTRAINT chk_items_link     CHECK ((item_type IN ('discount', 'tax')) = (linked_item_id IS NOT NULL)),
    CONSTRAINT chk_items_discount CHECK ((item_type = 'discount') = (discount_rule_id IS NOT NULL)),
    CONSTRAINT chk_items_tax      CHECK ((item_type = 'tax') = (tax_rule_id IS NOT NULL)),
    CONSTRAINT chk_items_sign     CHECK ((item_type = 'discount' AND amount < 0) OR (item_type <> 'discount' AND amount >= 0)),
    CONSTRAINT chk_items_quantity CHECK (quantity > 0),
    CONSTRAINT chk_items_service  CHECK (service_end IS NULL OR service_end >= service_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- The duplicate-billing guard: one invoice per subscription per period
CREATE TABLE billing_records (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    subscription_id BIGINT UNSIGNED NOT NULL,
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    invoice_id      BIGINT UNSIGNED NOT NULL,
    inputs          JSON NULL,                            -- snapshot of what billing used (Kill Bill invoice_billing_events)
    created_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_billing_period (subscription_id, period_start),
    UNIQUE KEY uq_billing_invoice (invoice_id),
    CONSTRAINT fk_billing_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id),
    CONSTRAINT fk_billing_invoice      FOREIGN KEY (invoice_id)      REFERENCES invoices (id),
    CONSTRAINT chk_billing_period      CHECK (period_end >= period_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE discount_applications (
    id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    discount_rule_id BIGINT UNSIGNED NOT NULL,
    invoice_id       BIGINT UNSIGNED NOT NULL,
    customer_id      BIGINT UNSIGNED NOT NULL,
    subscription_id  BIGINT UNSIGNED NULL,
    amount           DECIMAL(12,2) NOT NULL,              -- positive: total discount granted on this invoice
    reversed_at      DATETIME(3) NULL,                    -- set when the invoice is cancelled (UniBee 'rollback')
    applied_at       DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_discount_once_per_invoice (discount_rule_id, invoice_id),
    KEY idx_da_rule_customer (discount_rule_id, customer_id),
    KEY idx_da_rule_subscription (discount_rule_id, subscription_id),
    CONSTRAINT fk_da_rule         FOREIGN KEY (discount_rule_id) REFERENCES discount_rules (id),
    CONSTRAINT fk_da_invoice      FOREIGN KEY (invoice_id)       REFERENCES invoices (id),
    CONSTRAINT fk_da_customer     FOREIGN KEY (customer_id)      REFERENCES customers (id),
    CONSTRAINT fk_da_subscription FOREIGN KEY (subscription_id)  REFERENCES subscriptions (id),
    CONSTRAINT chk_da_amount      CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE payments (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    invoice_id      BIGINT UNSIGNED NOT NULL,
    method          ENUM('bank_transfer', 'card', 'cash', 'cheque', 'upi', 'other') NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    payment_date    DATE NOT NULL,
    note            VARCHAR(250) NULL,
    idempotency_key CHAR(36) NOT NULL,                    -- UUID generated by the form; a double submit can't record twice
    recorded_by     BIGINT UNSIGNED NOT NULL,
    created_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_payments_idempotency (idempotency_key),
    KEY idx_payments_invoice (invoice_id),
    KEY idx_payments_date (payment_date),
    CONSTRAINT fk_payments_invoice FOREIGN KEY (invoice_id)  REFERENCES invoices (id),
    CONSTRAINT fk_payments_user    FOREIGN KEY (recorded_by) REFERENCES users (id),
    CONSTRAINT chk_payments_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE billing_runs (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    as_of_date    DATE NOT NULL,
    triggered_by  BIGINT UNSIGNED NULL,                   -- NULL = scheduler
    dry_run       BOOLEAN NOT NULL DEFAULT FALSE,
    started_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    finished_at   DATETIME(3) NULL,
    due_count     INT UNSIGNED NOT NULL DEFAULT 0,
    created_count INT UNSIGNED NOT NULL DEFAULT 0,
    skipped_count INT UNSIGNED NOT NULL DEFAULT 0,
    failed_count  INT UNSIGNED NOT NULL DEFAULT 0,
    errors        JSON NULL,                              -- [{"subscription_id": .., "message": ..}]
    PRIMARY KEY (id),
    KEY idx_billing_runs_started (started_at),
    CONSTRAINT fk_billing_runs_user FOREIGN KEY (triggered_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Design decisions to be able to explain**

- **`billing_records UNIQUE (subscription_id, period_start)`** is the last line of defence: the database refuses a second invoice for the same period, whatever the code does (tested). Neither reference system has this: UniBee decides in application code from the latest invoice's status under a Redis lock, and Kill Bill recomputes items and writes only the difference.
- **`invoice_items` follows Kill Bill's `invoice_items`:** one table for every amount, a `type`, and `linked_item_id` for discounts and taxes. Like Kill Bill's table (which has no `updated_*` columns), items are **append-only**. `CHECK` constraints enforce the linking and sign rules (tested).
- **Invoice numbers are assigned on confirm**, from A's gapless counter. Drafts have `number = NULL`; a `UNIQUE` index allows many NULLs (tested). `CHECK (status IN ('draft','cancelled') OR number IS NOT NULL)` guarantees every confirmed or paid invoice has one (tested).
- **`payment_status`** is a generated column (`not_paid` / `partial` / `paid`) next to the problem's `status`, as Odoo has `payment_state` and Kill Bill derives balances separately. `CHECK (status <> 'paid' OR amount_paid = total)` means "Paid" can't be set early, and `CHECK (amount_paid <= total)` blocks overpayment (both tested).
- **`payments.idempotency_key`** (UUID from the form) makes a double submit harmless, like Kill Bill's unique `payments.external_key` and UniBee's `unique_id` columns (tested).
- **`billing_records.inputs`** keeps a JSON snapshot of what billing used (lines, prices, discounts considered), like Kill Bill's `invoice_billing_events`. JSON is fine here because it is a debugging log, not business data the app queries.
- Invoices are **never deleted** (drafts are cancelled), so item and discount foreign keys have no `ON DELETE CASCADE`. MySQL rejects deleting an invoice that still has items or a billing record (tested: error 1451).

---

## 3. The billing engine (`internal/logic/billing`)

### What we take from each reference

| Idea | Source (observed) | Our version |
|---|---|---|
| Poll for due subscriptions on a timer | UniBee: `gcron.AddSingleton(ctx, "@every 10s", ...)` selecting subscriptions whose `dunning_time` has passed | Nightly `gcron` job + "Run billing now" button; due = `status = 'active' AND next_billing_date <= today` |
| Lock while billing one subscription | UniBee: Redis `SET key 1 NX EX 60` per subscription. Kill Bill: global lock per account around invoicing and payment (`ACCNT_INV_PAY`) | MySQL row lock `FOR UPDATE SKIP LOCKED` on the subscription, held exactly as long as the transaction |
| Compute what *should* exist, write only what's missing | Kill Bill: "proposed items are ALL items since beginning of time", merged with existing items | Expected periods from `next_billing_date` to today, minus periods already in `billing_records` |
| Safety bound | Kill Bill: sanity check against duplicate items for a period (on by default) and at most **15** items per subscription per day | At most **31** periods per subscription per run; above that, refuse and log for a human |
| Preview without writing | Kill Bill dry-run invoices; UniBee `PreviewSubscriptionNextInvoice` | `GET /api/subscriptions/{id}/upcoming-invoice` and `dryRun` billing runs |

Why not Redis like UniBee: its lock is released with a plain `DEL` without checking the lock's value (`utility/jedis.go`), so if work outlives the 60-second expiry, a worker can delete another worker's lock. A MySQL row lock can't outlive its transaction, needs no extra service, and the guidelines favour fewer moving parts.

### Algorithm: `billing.Run(ctx, asOf, dryRun)`

```
run := insert billing_runs(as_of_date, dry_run)
lastID := 0
loop:
    ids := SELECT id FROM subscriptions
           WHERE status = 'active' AND next_billing_date <= :asOf AND id > :lastID
           ORDER BY id LIMIT 100                               -- keyset batches
    if empty: break
    lastID = max(ids)
    for each id:                                               -- one transaction per subscription
        g.DB().Transaction(ctx, func(ctx, tx) error {
            sub := SELECT * FROM subscriptions
                   WHERE id = :id AND status = 'active' FOR UPDATE SKIP LOCKED   -- raw SQL
            if none: skipped (another worker has it); return nil
            periods := C.PeriodStart(k) for k from the period at next_billing_date,
                       while start <= asOf
                         and (expiry_date IS NULL or start <= expiry_date)
                         and (scheduled_close_date IS NULL or start < scheduled_close_date)
            existing := SELECT period_start FROM billing_records WHERE subscription_id = :id
            missing := periods − existing
            if len(missing) > 31: return safetyBoundError         -- logged, nothing written
            for each period in missing:
                base := plan item + recurring product items
                        + one-time items only if no billing_record exists yet
                rules := B.ApplicableDiscounts(ctx, tx, ...)     -- locks rule rows by ascending id
                items := B.PriceItems(base, rules, taxes)
                if dryRun: collect; continue
                INSERT invoices (draft, number NULL), invoice_items (base first, then linked)
                INSERT billing_records (period, invoice_id, inputs JSON)
                INSERT discount_applications; UPDATE discount_rules SET times_used = times_used + 1
                if settings.auto_confirm_recurring_invoices: confirm (number from A's sequence)
            UPDATE subscriptions SET next_billing_date = first period start > asOf
            A.audit.Log(...)
        })
        on error 1213/1205 (deadlock / lock wait): retry once
        on other error: count failed, append {subscription_id, message} to billing_runs.errors
finish run with counts
```

### Why this is safe

| Risk | Protection | Tested? |
|---|---|---|
| Run twice / retried after a crash | Missing-period diff + `UNIQUE (subscription_id, period_start)` | Duplicate period rejected (DB test) |
| Partially saved invoice | Invoice, items, billing record, discount use and date update in one transaction | — (unit test in Go) |
| Missed days (server down) | The loop bills every missing period up to today | — |
| Two runs at once | `FOR UPDATE SKIP LOCKED` | Second session skipped the locked row in 0.01 s |
| Discount over-used in a batch | Row lock + `CHECK (times_used <= max_uses)` | Over-use rejected (DB test) |
| Runaway billing from a bug | Safety bound of 31 periods per run | — |
| One bad subscription | Per-subscription transaction; logged, the rest continue | — |

### Scheduling

A nightly `gcron.AddSingleton` job calls, in order: C's `lifecycle.ActivateDue` → `billing.Run` → C's `lifecycle.CloseDue`. The **"Run billing now"** button runs the same sequence. With A's **test clock** in development, the demo can move to 1 April and bill a whole month in seconds.

### Invoice lifecycle

| Action | From → To | Rules |
|---|---|---|
| `confirm` | draft → confirmed | Number from `sequence.Next`; `confirmed_at`; `due_date` from payment terms; items become read-only; bulk confirm |
| `cancel` | draft/confirmed → cancelled | Only if `amount_paid = 0`; reason required; set `reversed_at` on its `discount_applications` and decrement `times_used` (UniBee does the same with a "rollback" status on discount usage) |
| *(automatic)* | confirmed → paid | When `amount_paid = total` after a payment |
| `send` | confirmed or paid | Enqueue an `email` job with dedupe key `invoice-sent:{id}`, PDF attached; `sent_at` |
| `pdf` | any | `github.com/go-pdf/fpdf` (UniBee uses it for invoices): company header, items grouped by rule/rate, totals |

A cancelled invoice keeps its billing record, so the period isn't re-billed automatically.

### Recording a payment (one transaction)

1. `SELECT ... FROM invoices WHERE id = ? FOR UPDATE`
2. Status must be `confirmed`; `0 < amount <= total − amount_paid` (clear message with the balance)
3. `INSERT payments` with the form's `idempotency_key`. On error **1062** for that key, return the payment already recorded with it (HTTP 200): the double submit becomes harmless.
4. `amount_paid += amount`; if equal to `total`, `status = 'paid'`
5. `audit.Log`

### Overdue reminders (should-have)

A daily job enqueues email reminders for confirmed invoices 1, 7 and 15 days past due, with dedupe keys `overdue:{invoice}:{day}`, so a re-run never sends twice. This is a light version of Kill Bill's overdue module, which moves accounts through configurable overdue states.

---

## 4. Reporting definitions (write these into the README)

| Metric | Definition | Measured on 10k subs / 100k invoices |
|---|---|---|
| Active subscriptions + **MRR** | `COUNT(*)`, `SUM(recurring_monthly)` where `status = 'active'` | 19 ms |
| Revenue received (period) | `SUM(payments.amount)` by `payment_date` | 30 ms |
| Outstanding | `SUM(total − amount_paid)` where `status = 'confirmed'` | 99 ms |
| Overdue | `status = 'confirmed' AND due_date < today AND amount_paid < total`; list page 1 / count | 8 ms / 60 ms |
| Customer invoice list | by `customer_id`, newest first, 25 rows | 11 ms |
| ARR | MRR × 12 | — |
| Churn (period) | Subscriptions closed in the period whose close reason has `is_churn = TRUE`, by reason; churned MRR | — |

Timings were measured in this sandbox with MySQL 8.0.46 on seeded data, client start-up included; repeat them on your own machine in Phase 4. All aggregates run in SQL; every list is paginated.

---

## 5. API endpoints you own

| Method | Route | Access | Notes |
|---|---|---|---|
| POST | `/api/billing/runs` | Admin, Staff | `{ asOfDate?, dryRun? }`; returns the run summary |
| GET | `/api/billing/runs` | Admin, Staff | History with errors |
| GET | `/api/subscriptions/{id}/upcoming-invoice` | Admin, Staff, owning Customer | Dry-run preview of the next invoice |
| GET | `/api/invoices` | Admin, Staff | Filters: status, payment status, customer, subscription, dates, overdue; paginated |
| GET | `/api/invoices/{id}` | Admin, Staff | Items (linked), payments, balance |
| POST | `/api/invoices/{id}/actions/{confirm\|cancel\|send}` | Admin, Staff | |
| POST | `/api/invoices/actions/bulk-confirm` | Admin, Staff | Per-id result |
| GET | `/api/invoices/{id}/pdf` | Admin, Staff, owning Customer | |
| POST | `/api/invoices/{id}/payments` | Admin, Staff | `{ method, amount, paymentDate, note, idempotencyKey }` |
| GET | `/api/payments` | Admin, Staff | Filters: dates, method, customer |
| GET | `/api/reports/summary`, `/api/reports/overdue`, `/api/reports/revenue-by-month`, `/api/reports/mrr` | Admin, Staff | |
| GET | `/api/portal/invoices[/{id}]` | Customer | Own only, else 404 |

---

## 6. Frontend you own

- **Billing:** "Run billing now" with date and dry-run switch, run summary (due, created, skipped, failed with reasons), run history.
- **Invoices:** list with status and payment-status tags, filters, bulk confirm; detail with items grouped (base → its discount → its tax), payments and balance; actions; "Record payment" modal using A's `useIdempotencyKey()`.
- **Upcoming invoice** card on C's subscription detail page.
- **Finance dashboard:** AntD `Statistic` cards (MRR, active subscriptions, revenue, outstanding, overdue), date filter, overdue table, revenue-by-month chart, MRR by plan, churn by reason; each card links to its filtered list.
- **Customer tab** and **portal "My Invoices"** with PDF download.

---

## 7. What you depend on from others

| From | What | When |
|---|---|---|
| A | `clock.Today`, `sequence.Next`, `jobs.Enqueue`, `audit.Log`, settings, `auth.CustomerID`, idempotency hook | Phase 1 |
| B | `ApplicableDiscounts`, `PriceItems`, `TaxRulesFor` | Stub Phase 1, real Phase 2 |
| C | `PeriodStart`/`PeriodEnd`, `lifecycle.ActivateDue`/`CloseDue`, `recurring_monthly`, close reasons | Stub Phase 1, real Phase 2 |

You are the most downstream member: push for stubs early and build against them.

---

## 8. Phase-by-phase checklist

**Phase 0 — Kickoff (with team)**
- [ ] Walk everyone through the billing algorithm and the safety table

**Phase 1 — Foundation**
- [ ] Repositories for your tables; seed script skeleton

**Phase 2 — Core workflows**
- [ ] `billing.Run` with per-subscription transactions, diff, safety bound, dry run, run log
- [ ] Invoice actions, PDF, payments with idempotency
- [ ] Invoice and billing screens
- [ ] **Checkpoint 2 (team):** quote → active subscription → correct invoice with linked items

**Phase 3 — Integration**
- [ ] Nightly scheduler calling C's steps in order; upcoming-invoice preview
- [ ] Dashboard, portal invoices, send via job queue + MailHog, overdue reminders

**Phase 4 — Testing and hardening**
- [ ] Tests in section 9
- [ ] Seed 10,000 subscriptions and 100,000 invoices; time every page; `EXPLAIN` slow queries; record the table for reviewers

**Phase 5 — Demo prep**
- [ ] Demo data with due subscriptions, overdue invoices and partial payments

---

## 9. Tests and edge cases you must cover

- Run billing twice for the same date → 0 created, all skipped
- Crash after inserting items (inject an error) → nothing saved for that subscription; re-run creates it once
- Billing not run for 3 days on a daily plan → 3 invoices on the next run
- 33 missing periods → safety bound refuses and logs; nothing written
- 300 subscriptions due on one day → all billed; time recorded
- Two runs started together → each subscription billed once
- Discount with 1 use left and 5 eligible subscriptions → applied exactly once
- One-time product → first invoice only; paused, closed, future-start and end-of-term-closing subscriptions → correct periods only
- Items: discount and tax linked to the right base item; totals equal B's preview to the cent
- Draft has no number; confirming three invoices gives consecutive numbers; a rolled-back confirm consumes no number
- Payment over balance, on a draft, on a cancelled invoice → rejected; same idempotency key twice → one payment
- Partial then full payment → `partial` then `paid`; cancel with payments → rejected; cancel releases the discount use
- Overdue appears the day after `due_date`, disappears when fully paid; reminders never sent twice
- Customer A fetching customer B's invoice or PDF → 404

---

## 10. Git branches (suggested)

`feature/invoice-items`, `feature/billing-engine`, `feature/invoice-actions-pdf`, `feature/payments`, `feature/dashboard`, `feature/portal-invoices`, `feature/overdue-reminders`, `feature/seed-and-perf`

---

## 11. Your demo segment

1. Open a subscription's **upcoming invoice** preview.
2. Move the test clock to the billing date; click **Run billing now** → invoices with linked discount and tax items.
3. Click it again → 0 created, all skipped.
4. Confirm an invoice (number assigned now), record a partial payment, submit the same form twice (one payment), then pay the rest → Paid.
5. Open the dashboard on the large dataset: MRR, revenue, outstanding, overdue, churn, all well under two seconds.

---

## 12. Questions you should be ready to answer

- Exactly how do you guarantee no duplicate invoices and no skipped periods? How is that different from UniBee and Kill Bill?
- Why a MySQL row lock instead of a Redis lock?
- What does the safety bound protect against?
- Why are invoice items linked, and why are they never updated?
- Why is the invoice number assigned on confirm?
- How did you verify the two-second target?
- How does the full flow work from signup to dashboard? (Explain A, B and C at a high level.)
