module brightloop/reference/billingdate

go 1.22
