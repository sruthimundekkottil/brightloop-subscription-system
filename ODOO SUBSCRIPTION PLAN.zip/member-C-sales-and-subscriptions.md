# Member C — Sales & Subscriptions

**Project:** Brightloop Subscription Management System
**Stack:** Go 1.22 + GoFrame v2.6.4 · MySQL 8.0 · React 18 + TypeScript + Vite + Ant Design 5
**Modules owned:** Quotation templates, quotations, subscriptions and lines, the **lifecycle state machine**, **billing-period date logic**, renewals, pauses, closures, add-ons, MRR figures, and the portal's "My Subscriptions"

---

## 1. Your mission

You turn an offer into a running subscription and keep its status and dates correct. D's billing engine trusts your `next_billing_date`, your period calculation and your close dates completely, so date logic is the most important code you write. Every status change follows one state machine, is recorded in history, and respects the plan's settings.

---

## 2. Database tables you own

Copied from `db/migrations/000001_init.up.sql` (applied to MySQL 8.0.46; all 62 checks in `db/test_constraints.sh` pass).

```sql
CREATE TABLE payment_terms (
    id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name     VARCHAR(60) NOT NULL,                        -- 'Immediate', 'Net 15', 'Net 30'
    due_days INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_payment_terms_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE close_reasons (
    id       BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name     VARCHAR(80) NOT NULL,                        -- 'Too expensive', 'Renewed', 'Ended', 'Quotation expired'
    is_churn BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (id),
    UNIQUE KEY uq_close_reasons_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE quotation_templates (
    id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name             VARCHAR(150) NOT NULL,
    plan_id          BIGINT UNSIGNED NOT NULL,
    validity_days    INT UNSIGNED NOT NULL,
    payment_terms_id BIGINT UNSIGNED NULL,
    terms            TEXT NULL,
    notes            TEXT NULL,
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    created_by       BIGINT UNSIGNED NOT NULL,
    created_at       DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT fk_templates_plan       FOREIGN KEY (plan_id)          REFERENCES plans (id),
    CONSTRAINT fk_templates_terms      FOREIGN KEY (payment_terms_id) REFERENCES payment_terms (id),
    CONSTRAINT fk_templates_created_by FOREIGN KEY (created_by)       REFERENCES users (id),
    CONSTRAINT chk_templates_validity  CHECK (validity_days > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE quotation_template_lines (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    template_id BIGINT UNSIGNED NOT NULL,
    product_id  BIGINT UNSIGNED NOT NULL,
    variant_id  BIGINT UNSIGNED NULL,
    quantity    INT UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_tlines_template FOREIGN KEY (template_id) REFERENCES quotation_templates (id) ON DELETE CASCADE,
    CONSTRAINT fk_tlines_product  FOREIGN KEY (product_id)  REFERENCES products (id),
    CONSTRAINT fk_tlines_variant  FOREIGN KEY (variant_id)  REFERENCES product_variants (id),
    CONSTRAINT chk_tlines_quantity CHECK (quantity > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE subscriptions (
    id                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    number                VARCHAR(30) NOT NULL,           -- 'SUB-2026-00042' from number_sequences
    customer_id           BIGINT UNSIGNED NOT NULL,
    plan_id               BIGINT UNSIGNED NOT NULL,
    template_id           BIGINT UNSIGNED NULL,
    payment_terms_id      BIGINT UNSIGNED NOT NULL,
    status                ENUM('draft', 'quotation', 'confirmed', 'active', 'paused', 'closed') NOT NULL DEFAULT 'draft',
    start_date            DATE NOT NULL,
    expiry_date           DATE NULL,                      -- NULL = open-ended
    billing_anchor_date   DATE NULL,                      -- periods are computed from here (Kill Bill BCD / UniBee billing_cycle_anchor)
    next_billing_date     DATE NULL,                      -- read by D's billing engine
    quotation_valid_until DATE NULL,
    scheduled_close_date  DATE NULL,                      -- close at end of term (Kill Bill END_OF_TERM / UniBee cancel_at_period_end)
    recurring_total       DECIMAL(12,2) NOT NULL DEFAULT 0, -- per billing period, before tax and discounts
    recurring_monthly     DECIMAL(12,2) NOT NULL DEFAULT 0, -- normalised to one month → MRR
    renewed_from_id       BIGINT UNSIGNED NULL,
    terms                 TEXT NULL,
    salesperson_id        BIGINT UNSIGNED NULL,
    paused_at             DATETIME(3) NULL,
    closed_at             DATETIME(3) NULL,
    close_reason_id       BIGINT UNSIGNED NULL,
    close_note            VARCHAR(200) NULL,
    created_at            DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at            DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    open_renewal_marker   BIGINT UNSIGNED GENERATED ALWAYS AS
                          (IF(renewed_from_id IS NOT NULL AND status <> 'closed', renewed_from_id, NULL)) STORED,
    PRIMARY KEY (id),
    UNIQUE KEY uq_subscriptions_number (number),
    UNIQUE KEY uq_subscriptions_one_open_renewal (open_renewal_marker),
    KEY idx_subs_status_next_billing (status, next_billing_date),
    KEY idx_subs_status_expiry (status, expiry_date),
    KEY idx_subs_status_scheduled_close (status, scheduled_close_date),
    CONSTRAINT fk_subs_customer     FOREIGN KEY (customer_id)      REFERENCES customers (id),
    CONSTRAINT fk_subs_plan         FOREIGN KEY (plan_id)          REFERENCES plans (id),
    CONSTRAINT fk_subs_template     FOREIGN KEY (template_id)      REFERENCES quotation_templates (id),
    CONSTRAINT fk_subs_terms        FOREIGN KEY (payment_terms_id) REFERENCES payment_terms (id),
    CONSTRAINT fk_subs_renewed_from FOREIGN KEY (renewed_from_id)  REFERENCES subscriptions (id),
    CONSTRAINT fk_subs_salesperson  FOREIGN KEY (salesperson_id)   REFERENCES users (id),
    CONSTRAINT fk_subs_close_reason FOREIGN KEY (close_reason_id)  REFERENCES close_reasons (id),
    CONSTRAINT chk_subs_expiry      CHECK (expiry_date IS NULL OR expiry_date >= start_date),
    CONSTRAINT chk_subs_recurring   CHECK (recurring_total >= 0 AND recurring_monthly >= 0),
    CONSTRAINT chk_subs_closed      CHECK ((status = 'closed') = (closed_at IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE subscription_lines (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    subscription_id BIGINT UNSIGNED NOT NULL,
    product_id      BIGINT UNSIGNED NOT NULL,
    variant_id      BIGINT UNSIGNED NULL,
    quantity        INT UNSIGNED NOT NULL,
    unit_price      DECIMAL(12,2) NOT NULL,               -- agreed price, from B's GetUnitPrice
    amount          DECIMAL(14,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    PRIMARY KEY (id),
    KEY idx_sub_lines_subscription (subscription_id),
    CONSTRAINT fk_sub_lines_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE CASCADE,
    CONSTRAINT fk_sub_lines_product      FOREIGN KEY (product_id)      REFERENCES products (id),
    CONSTRAINT fk_sub_lines_variant      FOREIGN KEY (variant_id)      REFERENCES product_variants (id),
    CONSTRAINT chk_sub_lines_quantity    CHECK (quantity > 0),
    CONSTRAINT chk_sub_lines_price       CHECK (unit_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE subscription_status_history (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    subscription_id BIGINT UNSIGNED NOT NULL,
    from_status     ENUM('draft', 'quotation', 'confirmed', 'active', 'paused', 'closed') NULL,
    to_status       ENUM('draft', 'quotation', 'confirmed', 'active', 'paused', 'closed') NOT NULL,
    changed_by      BIGINT UNSIGNED NULL,                 -- NULL = scheduled job
    note            VARCHAR(255) NULL,
    changed_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_sub_history (subscription_id, changed_at),
    CONSTRAINT fk_sub_history_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE CASCADE,
    CONSTRAINT fk_sub_history_user         FOREIGN KEY (changed_by)      REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Design decisions to be able to explain**

- A quotation is a subscription in `draft`/`quotation` status, not a separate table: the number, lines and history stay continuous from offer to closure.
- `billing_anchor_date` is the date periods are counted from, like Kill Bill's bill cycle day (`billing_cycle_day_local`) and UniBee's `billing_cycle_anchor`. It is set to `start_date` on activation; periods are always computed from it, so they never drift.
- `scheduled_close_date` implements **close at end of term**: Kill Bill's `END_OF_TERM` cancellation policy and UniBee's `cancel_at_period_end`.
- **At most one open renewal per subscription:** MySQL has no partial unique index, so `open_renewal_marker` is a generated column that holds `renewed_from_id` only while the renewal isn't closed; a `UNIQUE` index on it blocks a second open renewal but allows a new one after the first is closed (both tested).
- `CHECK ((status = 'closed') = (closed_at IS NOT NULL))`: a closed subscription always has a close time, and only closed ones do (tested).
- `subscription_lines.amount` is a generated column (`quantity × unit_price`), so it can never disagree with its inputs (tested: 3 × 33.33 = 99.99).
- `recurring_total` / `recurring_monthly` are recalculated whenever lines change, so D gets **MRR** with one `SUM` (measured: 19 ms over 10,000 subscriptions).
- D's "what's due" query took 9 ms for a batch of 100 among 10,000 seeded subscriptions. At that size MySQL chose the primary key (because of `ORDER BY id`); the `(status, next_billing_date)` index is there for larger tables. Check with `EXPLAIN` in Phase 4.

**How our statuses map to the reference systems**

| Ours | Kill Bill entitlement state | UniBee subscription status |
|---|---|---|
| draft, quotation | — (quotes live outside Kill Bill) | 0 Init |
| confirmed (future start) | PENDING | 1 Pending |
| active | ACTIVE | 2 Active |
| paused | BLOCKED (via `blocking_states.block_billing`) | 6 Suspend |
| closed | CANCELLED | 4 Cancel / 5 Expire |

---

## 3. The lifecycle state machine

```
draft ──send──▶ quotation ──accept──▶ confirmed ──activate──▶ active ──close──▶ closed
  │                 │                                          │  ▲
  └────cancel───────┴──────────reject/cancel──▶ closed     pause│  │resume
                                                               ▼  │
                                                              paused
```

| Action | From → To | Guard (`CONFLICT` if false) |
|---|---|---|
| `send` | draft → quotation | ≥1 line; plan available on start date (B's `IsPlanAvailable`); total quantity ≥ `plan.min_quantity`. Sets `quotation_valid_until` = today + template days (or A's company default) |
| `accept` | quotation → confirmed | today ≤ `quotation_valid_until` |
| `activate` | confirmed → active | Sets `billing_anchor_date = start_date`, `next_billing_date = start_date`. Future start dates are activated by the daily job |
| `pause` | active → paused | `plan.can_pause`; sets `paused_at` |
| `resume` | paused → active | `next_billing_date` = first period start ≥ today (paused periods are never billed) |
| `renew` | active (unchanged) | `plan.can_renew`, has `expiry_date`, no open renewal. Creates a **new** subscription in `quotation` with `renewed_from_id`, same plan and lines (re-priced by B), `start_date = expiry + 1 day` |
| `close` | active/paused → closed, or scheduled | Body `{ when: "immediate" \| "end_of_period", reasonId, note }`. Immediate before expiry needs `plan.can_close_early`; sets `closed_at`. End of period sets `scheduled_close_date = next_billing_date` and stays active |
| `undo_close` | active (scheduled) | Clears `scheduled_close_date` before it happens (Kill Bill's `UNCANCEL`) |
| `cancel` | draft/quotation → closed | Reason required |

**Implementation rules**

- One `subscription.Transition(ctx, id, action, input, user)` holds this table. Nothing else writes `status`.
- Inside `g.DB().Transaction`: `SELECT ... FOR UPDATE` the subscription (GoFrame's `LockUpdate()` is fine here), check the guard, update, insert `subscription_status_history`, call A's `audit.Log`. Two staff clicking "close" at once: the second waits, then sees `closed` and gets `CONFLICT`.
- Lines are editable in `draft`/`quotation`. On an **active** subscription, staff may add or remove add-ons; the change applies from the next period (no proration), recalculates `recurring_*`, and is noted in history. D's invoices are unaffected because they snapshot items.

**Daily lifecycle steps** (D's nightly scheduler calls them in this order around billing):

1. `lifecycle.ActivateDue(ctx, today)`: `confirmed` with `start_date <= today` → `active`.
2. *(D's billing run)*
3. `lifecycle.CloseDue(ctx, today)`, each with a close reason:
   - `scheduled_close_date <= today` → closed ("Cancelled at end of term")
   - `plan.auto_close` and `expiry_date < today` → closed ("Ended"), unless a renewal of it is confirmed or active
   - an activated renewal → its original closed ("Renewed", not churn)
4. Past expiry with no auto-close: stays active, listed under **"Expired — action needed"**.

---

## 4. Billing-period date logic (`internal/logic/subscription/billingdate`)

Period *k* starts at `anchor + k × interval`, where the interval is the plan's period × `billing_interval_count`. Period *k* ends the day before period *k+1* starts.

**Go trap:** `time.AddDate` normalises overflow. Adding one month to 31 January gives 3 March (in 2026), not 28 February. Month and year steps must clamp to the last day of the month:

```go
// addMonthsClamped adds months to t, clamping the day to the target month's last day.
func addMonthsClamped(t time.Time, months int) time.Time {
    y, m, d := t.Date()
    first := time.Date(y, m+time.Month(months), 1, 0, 0, 0, 0, time.UTC)
    last := first.AddDate(0, 1, -1).Day()
    if d > last {
        d = last
    }
    return time.Date(first.Year(), first.Month(), d, 0, 0, 0, 0, time.UTC)
}

// PeriodStart returns the start of billing period k (k = 0 is the anchor).
func PeriodStart(anchor time.Time, period string, every, k int) time.Time {
    switch period {
    case "daily":
        return anchor.AddDate(0, 0, every*k)
    case "weekly":
        return anchor.AddDate(0, 0, 7*every*k)
    case "monthly":
        return addMonthsClamped(anchor, every*k)
    default: // "yearly"
        return addMonthsClamped(anchor, 12*every*k)
    }
}
```

Because every period is computed **from the anchor**, a 31 January subscription bills 31 Jan → 28 Feb → 31 Mar → 30 Apr, with no drift. These cases are checked by `reference/billingdate/billingdate_test.go` (passing on Go 1.22.2); copy the package and its tests into the backend in Phase 1.

| Function | Purpose | Used by |
|---|---|---|
| `PeriodStart(anchor, period, every, k)` / `PeriodEnd(...)` | Period boundaries | D |
| `NextPeriodOnOrAfter(sub, date)` | Resume, scheduled close | You, D |
| `MonthlyEquivalent(amount, period, every)` | `recurring_monthly`: daily × 365/12, weekly × 52/12, monthly × 1, yearly ÷ 12, each ÷ `every`, rounded to 2 dp | You, D |

---

## 5. API endpoints you own

| Method | Route | Access | Notes |
|---|---|---|---|
| GET/POST | `/api/quotation-templates` | Read: staff, admin; write: agree in kickoff | |
| GET/PATCH | `/api/quotation-templates/{id}` | Same | |
| GET | `/api/payment-terms`, `/api/close-reasons` | Logged in | Seeded |
| POST | `/api/subscriptions` | Staff, admin | Blank draft or `{ templateId, customerId, startDate }`; number from A's `sequence.Next` |
| GET | `/api/subscriptions` | Staff, admin | Filters: status, customer, plan, number, dates, "expired — action needed", "closing at end of term"; paginated |
| GET | `/api/subscriptions/{id}` | Staff, admin | Lines, pricing preview, history, `allowedActions`, renewal links |
| PATCH | `/api/subscriptions/{id}` | Staff, admin | Header fields in draft/quotation |
| PUT | `/api/subscriptions/{id}/lines` | Staff, admin | Draft/quotation; add-ons on active (next period) |
| POST | `/api/subscriptions/{id}/actions/{action}` | Staff, admin | Actions in section 3 |
| GET | `/api/portal/subscriptions[/{id}]` | Customer | Own only (A's `auth.CustomerID`), else 404 |
| POST | `/api/portal/subscriptions/{id}/actions/{action}` | Customer | `accept`; `pause`/`resume`/`close`/`undo_close` when the plan allows |

The detail response includes `allowedActions`, so the UI only shows valid buttons; the server re-checks every action.

---

## 6. Frontend you own

- **Templates:** list and form (plan, validity days, payment terms, terms text, product lines with variant picker).
- **New quotation:** customer → template or blank → lines prefilled and priced → edit quantities → live totals from B's `/api/pricing/preview` → save or send.
- **Subscription list:** AntD `Table` with status tags, quick filters per status, "Expired — action needed" and "Closing at end of term".
- **Subscription detail:** header, lines, recurring amount and monthly equivalent, AntD `Timeline` from history, renewal links, action buttons from `allowedActions`. The close dialog asks for a reason and "Now / At end of period".
- **Customer tab** and **portal "My Subscriptions"** with the customer actions above.

---

## 7. What you depend on from others

| From | What | When |
|---|---|---|
| A | Auth, `auth.CustomerID`, `clock.Today`, `sequence.Next`, `audit.Log`, settings, UI kit | Phase 1 |
| B | `UnitPrice`, `IsPlanAvailable`, `/api/pricing/preview` | Stub Phase 1, real Phase 2 |
| D | Calls your date functions and lifecycle steps | Phase 2 |

---

## 8. Phase-by-phase checklist

**Phase 0 — Kickoff (with team)**
- [ ] Walk the team through the state machine and the date rules

**Phase 1 — Foundation**
- [ ] Template and subscription CRUD APIs
- [ ] `billingdate` package with tests (month-end, leap year, every-N), exported for D

**Phase 2 — Core workflows**
- [ ] Create from template; `Transition` with guards, locking, history, audit
- [ ] Template, quotation, list and detail screens
- [ ] **Checkpoint 2 (team):** quote → active subscription → D generates a correct invoice

**Phase 3 — Integration**
- [ ] Lifecycle steps (activate, scheduled close, auto-close, renewal hand-off)
- [ ] Renewals, end-of-term close, add-ons; portal and customer tab

**Phase 4 — Testing and hardening**
- [ ] Tests in section 9

**Phase 5 — Demo prep**
- [ ] Seed subscriptions in every status, one expiring soon, one paused, one closing at end of term

---

## 9. Tests and edge cases you must cover

- Every invalid transition → `CONFLICT` with a clear message; expired quotation can't be accepted
- Quantity below plan minimum; plan unavailable on start date → rejected on send
- Concurrent close → one succeeds, one `CONFLICT`
- Dates: monthly from 31 Jan; yearly from 29 Feb 2024; weekly; daily; every-3-months; never use raw `AddDate` for months
- Future start → activated by the job on that date (move A's test clock to show it)
- Resume after a long pause → next billing date is the first period start on or after today; no back-billing
- Close at end of period → still active and billed for the current period, closed on `scheduled_close_date`; `undo_close` before then keeps it running
- Renewal: linked quotation starting the day after expiry; a second open renewal blocked (DB test); activating it closes the original as "Renewed"
- `recurring_monthly` correct for every period type; one-time products excluded
- Add-on on an active subscription → only the next invoice changes
- Customer A acting on customer B's subscription → 404

---

## 10. Git branches (suggested)

`feature/quotation-templates`, `feature/subscriptions-crud`, `feature/billing-dates`, `feature/subscription-lifecycle`, `feature/lifecycle-jobs`, `feature/renewals-and-closing`, `feature/portal-subscriptions`

---

## 11. Your demo segment

1. As staff, create a quotation from a template; lines and totals fill in automatically.
2. Send it; as the customer, accept it in the portal; as staff, activate it and show the timeline.
3. Try an invalid action and show it is refused.
4. Close a subscription "at end of period": it stays active until the date, then closes (use the test clock).
5. Renew a yearly subscription: a linked renewal quotation appears, starting the day after expiry.

---

## 12. Questions you should be ready to answer

- Why are billing periods computed from an anchor, and why can't you use `time.AddDate` for months?
- How do you prevent two people changing a status at the same moment?
- What's the difference between closing now and closing at the end of the period?
- Why does renewal create a new linked subscription?
- How does MySQL enforce "one open renewal" without partial indexes?
- How does the full flow work from signup to dashboard? (Explain A, B and D at a high level.)
