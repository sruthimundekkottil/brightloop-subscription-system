# Member A — Platform & Access Lead

**Project:** Brightloop Subscription Management System
**Stack:** Go 1.22 + GoFrame v2.6.4 · MySQL 8.0 · React 18 + TypeScript + Vite + Ant Design 5
**Modules owned:** Authentication, users and roles, staff management, customers, company settings, and the shared platform pieces: API conventions, middleware, clock, job queue, audit log, document numbering, shared UI kit
**Additional role:** Integration lead (repo, Docker Compose, migrations, README, merge coordination)

---

## 1. Your mission

Everyone else builds on your work, so it must be stable by the end of Phase 1: the team logs in as admin, staff and customer, every API is protected by your middleware, and migrations run on every laptop. You also own the platform services the billing engine depends on: the **clock** (with a test clock for the demo), the **job queue** for reliable emails, **gapless document numbers**, and the **audit log**. And you guarantee that **a customer can never see another customer's data**.

---

## 2. Database tables you own

These statements are copied from `db/migrations/000001_init.up.sql`, which has been applied to MySQL 8.0.46 and passes all 62 checks in `db/test_constraints.sh`.

```sql
CREATE TABLE users (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email         VARCHAR(254) NOT NULL COLLATE utf8mb4_0900_ai_ci, -- case-insensitive collation → UNIQUE is case-insensitive
    password_hash VARCHAR(255) NOT NULL,                              -- bcrypt
    role          ENUM('admin', 'staff', 'customer') NOT NULL,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at    DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE customers (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id         BIGINT UNSIGNED NULL,                 -- NULL if staff created the customer without a login
    name            VARCHAR(150) NOT NULL,
    company_name    VARCHAR(150) NULL,
    phone           VARCHAR(30) NULL,
    billing_address TEXT NULL,
    created_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    updated_at      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_customers_user (user_id),
    KEY idx_customers_name (name),
    CONSTRAINT fk_customers_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE staff_profiles (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    BIGINT UNSIGNED NOT NULL,
    full_name  VARCHAR(150) NOT NULL,
    job_title  VARCHAR(100) NULL,
    created_by BIGINT UNSIGNED NOT NULL,                  -- must be an admin (checked in the service layer)
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_user (user_id),
    CONSTRAINT fk_staff_user       FOREIGN KEY (user_id)    REFERENCES users (id),
    CONSTRAINT fk_staff_created_by FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE password_reset_tokens (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    BIGINT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,                         -- SHA-256 hex of the emailed token
    expires_at DATETIME(3) NOT NULL,
    used_at    DATETIME(3) NULL,                          -- single use
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    UNIQUE KEY uq_reset_token_hash (token_hash),
    KEY idx_reset_tokens_user (user_id),
    CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE company_settings (
    id                              TINYINT UNSIGNED NOT NULL DEFAULT 1,
    company_name                    VARCHAR(150) NOT NULL DEFAULT 'Brightloop Software',
    address                         TEXT NULL,
    currency_code                   CHAR(3) NOT NULL DEFAULT 'INR',
    invoice_prefix                  VARCHAR(10) NOT NULL DEFAULT 'INV',
    default_quotation_validity_days INT UNSIGNED NOT NULL DEFAULT 30,
    auto_confirm_recurring_invoices BOOLEAN NOT NULL DEFAULT FALSE,
    test_clock_date                 DATE NULL,           -- honoured only when APP_ENV=development; forward-only
    updated_at                      DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    CONSTRAINT chk_company_settings_single_row CHECK (id = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Gapless document numbers (MySQL has no sequences; a locked counter row also rolls back cleanly)
CREATE TABLE number_sequences (
    name       VARCHAR(40) NOT NULL,                      -- e.g. 'subscription-2026', 'invoice-2026'
    next_value BIGINT UNSIGNED NOT NULL DEFAULT 1,
    PRIMARY KEY (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- DB-backed job queue / transactional outbox (Kill Bill notifications pattern)
CREATE TABLE job_queue (
    id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    queue_name   VARCHAR(64) NOT NULL,                    -- 'email', 'overdue-reminder'
    dedupe_key   VARCHAR(150) NULL,                       -- e.g. 'invoice-sent:42'; NULLs allowed many times
    payload      JSON NOT NULL,
    effective_at DATETIME(3) NOT NULL,                    -- run no earlier than this
    state        ENUM('available', 'processing', 'done', 'failed') NOT NULL DEFAULT 'available',
    attempts     INT UNSIGNED NOT NULL DEFAULT 0,
    max_attempts INT UNSIGNED NOT NULL DEFAULT 5,
    locked_by    VARCHAR(64) NULL,
    locked_until DATETIME(3) NULL,
    last_error   TEXT NULL,
    created_at   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    processed_at DATETIME(3) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_jobs_dedupe (dedupe_key),
    KEY idx_jobs_ready (state, effective_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Audit trail (Kill Bill audit_log / UniBee merchant_operation_log)
CREATE TABLE audit_log (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    table_name VARCHAR(64) NOT NULL,
    record_id  BIGINT UNSIGNED NOT NULL,
    action     VARCHAR(40) NOT NULL,                      -- 'create', 'update', 'confirm', 'cancel', ...
    changed_by BIGINT UNSIGNED NULL,                      -- NULL = system job
    reason     VARCHAR(255) NULL,
    changes    JSON NULL,                                 -- {"field": [old, new]}
    created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    PRIMARY KEY (id),
    KEY idx_audit_target (table_name, record_id),
    KEY idx_audit_user (changed_by),
    CONSTRAINT fk_audit_user FOREIGN KEY (changed_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```

**Design decisions to be able to explain**

- `users` holds login identity only; `customers` holds the business profile, so staff can create a customer before the customer registers.
- **One account per email, case-insensitively, enforced by MySQL:** the `email` column uses the case-insensitive collation `utf8mb4_0900_ai_ci`, so `UNIQUE` treats `Cust@Shop.test` and `cust@shop.TEST` as the same (tested). The service still trims and lower-cases emails before saving.
- Reset tokens are stored as SHA-256 hashes, so a database leak doesn't expose usable links.
- `company_settings` is a single row guaranteed by `CHECK (id = 1)` (tested).
- `number_sequences` gives **gapless** numbers. MySQL has no sequences, and a locked counter row is actually better for invoices: if the transaction rolls back, the increment rolls back too (tested). PostgreSQL sequences, used in our earlier plan, do not roll back.
- `job_queue` is a transactional outbox modelled on Kill Bill's `notifications` table (`effective_date`, `processing_state`, `processing_owner`, `error_count`): a job is inserted **in the same transaction** as the business change, so an email is never sent for a change that rolled back, and a change is never saved without its email.
- `audit_log` follows Kill Bill's `audit_log` and UniBee's `merchant_operation_log`: who changed what, when and why.

---

## 3. Team-wide conventions you define (write these into the README on day one)

**Project layout** (GoFrame's standard layout, the same one UniBee's `unibee-api` uses):

```
backend/
  main.go
  manifest/config/config.yaml     -- DB link, SMTP, JWT secret, APP_ENV
  api/{auth,admin,portal}/        -- request/response structs with g.Meta route tags
  internal/
    cmd/  consts/  controller/    -- thin HTTP handlers
    logic/{auth,catalog,pricing,subscription,billing,payment,report,platform}/
    dao/  model/entity/           -- generated by `gf gen dao`
    cronjob/                      -- gcron registrations
  db/migrations/                  -- golang-migrate SQL files
frontend/
  src/{routes.tsx, requests/, stores/, components/, pages/}
docker-compose.yaml               -- mysql, mailhog, api, web
```

**API definition style** (as in UniBee's `api/` folder):

```go
type CreatePlanReq struct {
    g.Meta `path:"/plans" method:"post" tags:"Plans" summary:"Create plan"`
    Name          string `json:"name" v:"required|length:1,150"`
    BillingPeriod string `json:"billingPeriod" v:"required|in:daily,weekly,monthly,yearly"`
}
```

Use resource routes (`POST /api/plans`, `POST /api/subscriptions/{id}/actions/{action}`), not UniBee's `/xxx/update` style, because the guidelines ask for APIs built around resources.

**Success response**
```json
{ "data": { ... }, "meta": { "page": 1, "pageSize": 25, "total": 340 } }
```

**Error response**
```json
{ "error": { "code": "VALIDATION_ERROR", "message": "Please fix the highlighted fields.", "fields": { "email": "Enter a valid email address." } } }
```

| Code | HTTP | When |
|---|---|---|
| `VALIDATION_ERROR` | 422 | Bad input; `fields` maps field → message |
| `UNAUTHENTICATED` | 401 | No or expired session |
| `FORBIDDEN` | 403 | Logged in but wrong role |
| `NOT_FOUND` | 404 | Missing record **and** another customer's record |
| `CONFLICT` | 409 | Duplicate email, invalid status transition, already-billed period |
| `INTERNAL_ERROR` | 500 | Unexpected; generic message, full detail only in logs |

Your error middleware maps MySQL errors so users never see raw database messages: **1062** (duplicate key) → `CONFLICT`, **3819** (check constraint violated) → `VALIDATION_ERROR`, **1213/1205** (deadlock / lock wait timeout) → retry the transaction once, then `CONFLICT`.

**Other conventions:** money is `DECIMAL(12,2)` in MySQL, `decimal.Decimal` (`github.com/shopspring/decimal`) in Go and a string (`"1560.00"`) in JSON; dates are `YYYY-MM-DD`; timestamps are UTC (`loc=UTC` in the DSN, as UniBee does); lists take `page`, `pageSize` (max 100), `sort` and filters.

**Two GoFrame traps (verified in GoFrame v2.6.4 source):**

1. `gf gen dao` maps `DECIMAL` columns to **`float64` by default**. Configure `typeMapping` so money becomes `decimal.Decimal`:
   ```yaml
   gfcli:
     gen:
       dao:
         - link: "mysql:root:secret@tcp(127.0.0.1:3306)/brightloop"
           typeMapping:
             decimal:
               type:   decimal.Decimal
               import: github.com/shopspring/decimal
   ```
   Add a Phase 1 test that reads a `DECIMAL` column through the DAO and asserts the exact string (`"1180.00"`). If it fails, map `decimal` to `string` and convert with `decimal.NewFromString`. Never use `float64` for money.
2. `Model.LockUpdate()` only adds `FOR UPDATE`; there is no `SKIP LOCKED` helper. Write those queries as raw SQL inside `g.DB().Transaction(ctx, func(ctx context.Context, tx gdb.TX) error { ... })`.

---

## 4. Platform services you provide to the team

Ship stubs in the first hours so B, C and D can call them.

| Package / function | Purpose | Used by |
|---|---|---|
| `middleware.Auth`, `middleware.RequireRole(roles...)` | JWT (httpOnly cookie, `golang-jwt/jwt/v5`) and role checks | All |
| `auth.CustomerID(ctx)` | The logged-in customer's id; every portal query **must** filter by it | C, D |
| `clock.Today(ctx)` | Today's date. In `APP_ENV=development`, returns `company_settings.test_clock_date` when set | C, D |
| `sequence.Next(ctx, tx, name)` | Next gapless number inside the caller's transaction | C (subscriptions), D (invoices) |
| `jobs.Enqueue(ctx, tx, queue, dedupeKey, payload, effectiveAt)` | Insert a job in the caller's transaction | D (emails, reminders), A (reset emails) |
| `audit.Log(ctx, tx, table, id, action, reason, changes)` | Audit entry in the caller's transaction | All |
| `settings.Get(ctx)` | Company settings | C, D |

**`sequence.Next` implementation:**

```sql
INSERT INTO number_sequences (name, next_value) VALUES (?, 1)
    ON DUPLICATE KEY UPDATE name = name;               -- create the counter on first use
SELECT next_value FROM number_sequences WHERE name = ? FOR UPDATE;
UPDATE number_sequences SET next_value = next_value + 1 WHERE name = ?;
```

Format as `INV-2026-00001` (prefix from settings, counter name per year).

**Test clock** (Kill Bill's `ClockMock` + `/test/clock` endpoint; UniBee's per-subscription test clock):
- `PUT /api/dev/clock { "date": "2026-04-01" }`, admin only, **registered only when `APP_ENV=development`**.
- **Forward-only.** UniBee rejects moving a test clock backwards, and Kill Bill's `TestResource` warns that moving the clock back and forth on a running system may cause weird side effects.
- Every date decision in the code goes through `clock.Today(ctx)`. Calling `time.Now()` directly in business logic is a review blocker.

**Job worker** (`gcron.AddSingleton(ctx, "@every 10s", ...)`, the same cadence UniBee uses for its billing job):

1. In a transaction: `SELECT id ... FROM job_queue WHERE state = 'available' AND effective_at <= ? ORDER BY id LIMIT 20 FOR UPDATE SKIP LOCKED`, then set those rows to `processing` with `locked_by` and `locked_until`.
2. Outside the transaction, run each job (send the email through SMTP).
3. On success: `state = 'done'`, `processed_at`. On failure: `attempts + 1`, `last_error`, `effective_at = now + 2^attempts minutes`, back to `available`; after `max_attempts`, `failed`.
4. Recover stuck jobs: `processing` rows whose `locked_until` has passed go back to `available`.

`AddSingleton` only prevents overlap inside one process; `SKIP LOCKED` makes it safe across processes too (verified: a second session skipped the locked row and returned immediately).

---

## 5. API endpoints you own

| Method | Route | Access | Notes |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Creates `users` (customer) + `customers` row in **one transaction** |
| POST | `/api/auth/login` | Public | Same error for wrong email or wrong password |
| POST | `/api/auth/logout` | Logged in | Clears cookie |
| GET | `/api/auth/me` | Logged in | id, email, role, customerId |
| POST | `/api/auth/forgot-password` | Public | **Always 200**; if the account exists, enqueues the reset email via `job_queue` |
| POST | `/api/auth/reset-password` | Public | Token + new password; marks token used; invalidates other tokens |
| POST | `/api/staff` | Admin | User (staff) + staff profile in one transaction |
| GET | `/api/users` | Admin | Paginated, filter by role/active |
| PATCH | `/api/users/{id}/status` | Admin | Activate/deactivate (not yourself) |
| GET/POST | `/api/customers` | Admin, Staff | Search by name/email |
| GET/PATCH | `/api/customers/{id}` | Admin, Staff | |
| GET/PATCH | `/api/portal/profile` | Customer | Own profile only |
| GET/PUT | `/api/settings` | Read: admin, staff; write: admin | Company settings |
| GET | `/api/audit-log` | Admin | Filter by table, record, user, date |
| PUT | `/api/dev/clock` | Admin, development only | Forward-only test clock |

**Password rule — must be identical on server and client.** The problem says *more than* eight characters, so the minimum is 9.

- **Go's `regexp` (RE2) has no lookaheads**: `^(?=.*[a-z])...` fails to compile (tested: `invalid or unsupported Perl syntax: (?=`). Check each rule separately.
- **Don't use GoFrame's built-in `password3` rule**: its source shows 6–18 characters and a required digit, which is not the problem's rule.
- **bcrypt rejects passwords over 72 bytes** (`golang.org/x/crypto/bcrypt` returns `ErrPasswordTooLong`), so 72 bytes is the maximum.

```go
var (
    hasUpper   = regexp.MustCompile(`[A-Z]`)
    hasLower   = regexp.MustCompile(`[a-z]`)
    hasSpecial = regexp.MustCompile(`[^A-Za-z0-9]`)
)

func PasswordProblems(p string) map[string]string {
    probs := map[string]string{}
    if utf8.RuneCountInString(p) < 9 { probs["length"] = "Use more than 8 characters." }
    if len(p) > 72                   { probs["maxLength"] = "Use at most 72 bytes." }
    if !hasUpper.MatchString(p)      { probs["upper"] = "Add an uppercase letter." }
    if !hasLower.MatchString(p)      { probs["lower"] = "Add a lowercase letter." }
    if !hasSpecial.MatchString(p)    { probs["special"] = "Add a special character." }
    return probs
}
```

In TypeScript use the same three character classes, count characters with `[...p].length` (code points, matching `utf8.RuneCountInString`) and bytes with `new TextEncoder().encode(p).length`.

**Reset flow:** 32 random bytes (`crypto/rand`) → email the raw token in a link (queued) → store SHA-256 hex with a 30-minute expiry → on reset, hash the incoming token, check unexpired and unused, update the password, set `used_at`.

**Email:** SMTP from Go's standard `net/smtp` to **MailHog** in Docker Compose. UniBee uses the SendGrid API; we don't, because the guidelines discourage third-party APIs and MailHog runs locally.

---

## 6. Frontend you own

Ant Design 5 for all components (as UniBee's portals), Zustand for session state, axios with one interceptor that turns the error format into field errors and `message.error` toasts, React Router 6 with role guards.

- **Auth screens:** login, register (live password checklist), forgot and reset password.
- **App shell:** AntD `Layout` with role-based `Menu`; admin sees configuration, staff sees operations, customers see the portal only.
- **Admin:** staff list and "Add staff" form; activate/deactivate with `Popconfirm`; **Settings** page; **audit log** table; in development, a **test clock** card on the settings page.
- **Customers (staff/admin):** list with search and pagination, detail page with tabs C and D fill in.
- **Portal shell:** "My Subscriptions" (C) and "My Invoices" (D).
- **Shared kit:** money and date formatters (`dayjs`), `StatusTag`, empty and error states, `useIdempotencyKey()` hook (`crypto.randomUUID()` when a form opens) used by D's payment dialog.

Agree theme tokens in the kickoff and set them once in AntD's `ConfigProvider`.

---

## 7. What you depend on from others

| From | What | When |
|---|---|---|
| C | Subscriptions tab for customer detail and portal | Phase 3 |
| D | Invoices tab for customer detail and portal | Phase 3 |

You are mostly upstream; others depend on you.

---

## 8. Phase-by-phase checklist

**Phase 0 — Kickoff (with team)**
- [ ] Repo, protected `main`, PR template, branch rules
- [ ] Walk the team through `000001_init.up.sql` and `test_constraints.sh`
- [ ] Agree response format, error mapping, theme

**Phase 1 — Foundation**
- [ ] `docker-compose.yaml`: `mysql:8.0`, `mailhog`, API, web; `.env.example`
- [ ] golang-migrate wired (`migrate -path db/migrations -database "mysql://...?multiStatements=true" up`); `test_constraints.sh` passes on every laptop
- [ ] `gf gen dao` with the decimal `typeMapping`, and the decimal round-trip test
- [ ] Seed: admin, staff, customer, company settings row, payment terms, close reasons
- [ ] Register/login/logout/me with the password rule and bcrypt
- [ ] Middleware, error mapping, `clock`, `sequence`, `jobs`, `audit` stubs merged
- [ ] **Checkpoint 1:** clean DB → migrate → seed → login with all three roles on every machine

**Phase 2 — Core workflows**
- [ ] Forgot/reset password via job queue + MailHog
- [ ] Job worker with retries and stuck-job recovery
- [ ] Staff creation, app shell, role menus, route guards, shared kit
- [ ] Customers; settings page; test clock (development only)

**Phase 3 — Integration**
- [ ] Portal shell with C and D views
- [ ] Review every portal endpoint for the `auth.CustomerID` filter
- [ ] Audit log screen; merge coordination

**Phase 4 — Testing and hardening**
- [ ] Tests in section 9; clean-machine setup test from the README

**Phase 5 — Demo prep**
- [ ] README: setup, env vars, migrate, seed, run, test, architecture diagram

---

## 9. Tests and edge cases you must cover

- Duplicate email in a different case → "already registered" (DB test passes; also test the API message)
- Password with 8 characters; missing uppercase, lowercase or special; 73 bytes → each rejected with its own message, identically on client and server
- Login with wrong password and unknown email → identical message; deactivated user can't log in
- Reset token expired, reused or random → rejected; forgot-password for unknown email → still 200
- Staff calling `POST /api/staff` → 403; customer calling admin/staff endpoints → 403
- Customer A requesting customer B's subscription or invoice → 404 (test on C's and D's endpoints too)
- Rolled-back transaction → no job queued, no number consumed
- Email job fails (stop MailHog) → retried with backoff, then `failed`; the business change is not affected
- Test clock: moving backwards rejected; endpoint absent when `APP_ENV` is not `development`

---

## 10. Git branches (suggested)

`feature/repo-setup`, `feature/migrations`, `feature/auth-core`, `feature/auth-password-reset`, `feature/platform-jobs-clock-audit`, `feature/staff-management`, `feature/customers-settings`, `feature/app-shell-ui-kit`, `feature/portal-shell`

---

## 11. Your demo segment

1. Register with a weak password → rule feedback; register successfully.
2. Forgot password → the email appears in MailHog → reset works.
3. As admin, create a staff member; log in as staff and show the restricted menu.
4. Show the audit log entry for the staff creation.
5. Log in as the customer and show the portal only exposes their own data.

---

## 12. Questions you should be ready to answer

- How is "one account per email" guaranteed, including different letter cases and concurrent requests?
- Why can't the password rule be one Go regex, and why not GoFrame's `password3` rule?
- Why does an email go through `job_queue` instead of being sent directly?
- Why are invoice numbers gapless with a counter row but not with a PostgreSQL sequence?
- Why no Redis, when UniBee uses it?
- How does the whole system fit together? (Be able to explain B, C and D at a high level.)
